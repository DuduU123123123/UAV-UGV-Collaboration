import copy
import tempfile
import unittest
from pathlib import Path

from changping_min_solver import (
    apply_parameter_overrides,
    build_context,
    load_instance,
    solve,
    validate_instance,
    validate_solution,
)
from run_experiments import build_manifest_row, run_experiment_grid
from run_case_analysis import run_case_analysis


ROOT = Path(__file__).resolve().parent


class ChangpingMinimumSolverTests(unittest.TestCase):
    def load_base(self) -> dict:
        return load_instance(ROOT / "data" / "changping_min_instance.json")

    def load_demo(self) -> dict:
        return load_instance(ROOT / "data" / "changping_feasible_demo.json")

    def test_base_instance_structure_and_model_flags(self) -> None:
        data = self.load_base()
        validate_instance(data)
        self.assertEqual(len(data["stations"]), 6)
        self.assertEqual(len(data["segments"]), 5)
        self.assertEqual(len(data["directed_vehicle_arcs"]), 10)
        self.assertEqual(sum(row["distance_m"] for row in data["segments"]), 10797)
        self.assertEqual(data["parameters"]["begin_time_min"], 0)
        self.assertEqual(data["parameters"]["end_time_min"], 120)
        self.assertTrue(data["parameters"]["all_tasks_mandatory"])
        self.assertTrue(data["parameters"]["all_resources_mandatory"])

    def test_default_demo_is_feasible_and_fully_validated(self) -> None:
        data = self.load_demo()
        result = solve(build_context(data))
        self.assertTrue(result["feasible"])
        self.assertEqual(set(result["completed_task_ids"]), {"T01", "T03", "T04"})
        self.assertEqual(result["final_state"]["station_id"], "S06")
        self.assertEqual(result["objective"]["finish_time_min"], 95)
        self.assertEqual(result["objective"]["elapsed_time_min"], 95)
        self.assertLessEqual(result["objective"]["swaps_used"], 2)
        self.assertTrue(result["validation"]["model_constraints_satisfied"])
        self.assertTrue(result["validation"]["reported_feasible_consistent"])
        self.assertFalse(result["validation"]["violations"])

    def test_full_instance_is_reported_infeasible_but_partial_path_is_valid(self) -> None:
        data = self.load_base()
        result = solve(build_context(data))
        self.assertFalse(result["feasible"])
        self.assertGreaterEqual(len(result["completed_task_ids"]), 3)
        self.assertTrue(result["validation"]["valid_executed_path"])
        self.assertFalse(result["validation"]["model_constraints_satisfied"])
        self.assertTrue(result["validation"]["reported_feasible_consistent"])

    def test_shift_end_is_an_effective_constraint(self) -> None:
        data = self.load_demo()
        data["resources"]["mobile_nests"][0]["shift_end_min"] = 90
        result = solve(build_context(data))
        self.assertFalse(result["feasible"])
        self.assertEqual(result["effective_parameters"]["shift_end_min"], 90)
        self.assertTrue(all(action["end_min"] <= 90 for action in result["actions"]))
        self.assertTrue(result["validation"]["valid_executed_path"])

    def test_nonzero_begin_time_is_used_as_the_time_origin(self) -> None:
        data = self.load_demo()
        offset = 480
        data["parameters"]["begin_time_min"] += offset
        data["parameters"]["end_time_min"] += offset
        nest = data["resources"]["mobile_nests"][0]
        nest["shift_start_min"] += offset
        nest["shift_end_min"] += offset
        for task in data["tasks"]:
            task["earliest_start_min"] += offset
            task["latest_finish_min"] += offset
        result = solve(build_context(data))
        self.assertTrue(result["feasible"])
        self.assertEqual(result["objective"]["finish_time_min"], 575)
        self.assertEqual(result["objective"]["elapsed_time_min"], 95)
        self.assertEqual(result["actions"][0]["start_min"], 480)
        self.assertTrue(result["validation"]["model_constraints_satisfied"])

    def test_ground_wait_before_launch_is_considered(self) -> None:
        data = self.load_base()
        data["tasks"] = [copy.deepcopy(data["tasks"][0])]
        data["task_locations"] = [copy.deepcopy(data["task_locations"][0])]
        data["tasks"][0]["earliest_start_min"] = 30
        data["tasks"][0]["latest_finish_min"] = 60
        data["resources"]["mobile_nests"][0]["spare_battery_sets"] = 0
        result = solve(build_context(data))
        self.assertTrue(result["feasible"])
        service = next(action for action in result["actions"] if action["type"] == "joint_sortie_service")
        self.assertEqual(service["launch_min"], 25)
        self.assertEqual(service["prelaunch_wait_min"], 25)
        self.assertEqual(service["aerial_wait_before_service_min"], 0)
        self.assertEqual(service["drone_active_min"], 15)
        self.assertTrue(result["validation"]["model_constraints_satisfied"])

    def test_initial_pairing_is_validated(self) -> None:
        data = self.load_demo()
        data["resources"]["uavs"][0]["assigned_nest_id"] = "UNKNOWN"
        with self.assertRaisesRegex(ValueError, "assigned_nest_id"):
            validate_instance(data)

    def test_service_duration_is_rounded_up_to_time_step(self) -> None:
        data = self.load_base()
        data["tasks"] = [copy.deepcopy(data["tasks"][0])]
        data["task_locations"] = [copy.deepcopy(data["task_locations"][0])]
        data["tasks"][0]["service_time_min"] = 7
        result = solve(build_context(data))
        self.assertTrue(result["feasible"])
        service = next(action for action in result["actions"] if action["type"] == "joint_sortie_service")
        self.assertEqual(service["service_end_min"] - service["service_start_min"], 10)
        self.assertTrue(result["validation"]["model_constraints_satisfied"])

    def test_detailed_output_contains_reporting_fields(self) -> None:
        result = solve(build_context(self.load_demo()))
        self.assertEqual(result["solution_kind"], "FULL")
        self.assertEqual(result["task_result"]["completion_rate_pct"], 100.0)
        self.assertEqual(
            [row["task_id"] for row in result["uav_task_assignments"]],
            ["T01", "T03", "T04"],
        )
        self.assertGreaterEqual(result["runtime_ms"], 0)
        for action in result["actions"]:
            self.assertEqual(action["uav_id"], "U01")
            self.assertEqual(action["nest_id"], "B01")
            self.assertEqual(action["current_soc_pct"], action["soc_after_pct"])
            self.assertIn("swaps_used_before", action)
            self.assertIn("swaps_used_after", action)

    def test_validator_detects_tampered_action_state(self) -> None:
        context = build_context(self.load_demo())
        result = copy.deepcopy(solve(context))
        result["actions"][0]["current_soc_pct"] = 999
        validation = validate_solution(context, result)
        self.assertFalse(validation["passed"])
        self.assertTrue(
            any(row["constraint"] == "resource_state_reporting" for row in validation["violations"])
        )

    def test_linked_end_time_override_is_explicit_and_feasible(self) -> None:
        data = self.load_base()
        apply_parameter_overrides(
            data,
            end_time_min=135,
            spare_batteries=4,
            deadline_policy="linked",
        )
        validate_instance(data)
        self.assertEqual(data["parameters"]["end_time_min"], 135)
        self.assertEqual(data["resources"]["mobile_nests"][0]["shift_end_min"], 135)
        deadlines = {task["task_id"]: task["latest_finish_min"] for task in data["tasks"]}
        self.assertEqual(deadlines["T04"], 135)
        self.assertEqual(deadlines["T05"], 135)
        result = solve(build_context(data))
        self.assertTrue(result["feasible"])
        self.assertTrue(result["validation"]["passed"])

    def test_manifest_and_one_case_batch_run(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output_root = Path(temp_dir) / "experiments"
            manifest, summary = run_experiment_grid(
                input_path=ROOT / "data" / "changping_min_instance.json",
                output_root=output_root,
                end_times=[135],
                battery_counts=[4],
                nest_speeds=[15.0],
                uav_speeds=[3.0],
                endurance_minutes=[35.0],
                reserve_socs=[20],
                swap_times=[5.0],
                reverse_options=[False],
                deadline_policy="linked",
                max_labels=500_000,
            )
            self.assertEqual(len(manifest), 1)
            self.assertTrue(manifest[0]["feasible"])
            self.assertTrue(manifest[0]["validation_passed"])
            self.assertEqual(summary["minimum_feasible_tested_end_time_min"], 135)
            self.assertTrue((output_root / "experiment_matrix.csv").exists())
            self.assertTrue((output_root / "run_manifest.json").exists())
            self.assertTrue((output_root / "batch_summary.json").exists())
            self.assertTrue(
                (output_root / manifest[0]["experiment_id"] / "effective_instance.json").exists()
            )
            row = build_manifest_row("test", solve(build_context(self.load_demo())))
            self.assertEqual(row["completed_task_count"], 3)

    def test_phase_one_case_analysis_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output_root = Path(temp_dir) / "case_analysis"
            summary = run_case_analysis(
                input_path=ROOT / "data" / "changping_min_instance.json",
                output_root=output_root,
                max_end_time=135,
                max_batteries=4,
                max_labels=500_000,
            )
            selected = summary["minimum_feasible_tested_solution"]
            self.assertEqual(selected["window_length_min"], 135)
            self.assertEqual(selected["spare_battery_sets"], 4)
            self.assertTrue(summary["selected_validation"]["model_constraints_satisfied"])
            self.assertEqual(len(summary["selected_task_schedule"]), 5)
            self.assertTrue((output_root / "case_analysis_report.md").exists())
            self.assertTrue((output_root / "selected_minimum_feasible" / "timeline.csv").exists())
            self.assertTrue((output_root / "selected_minimum_feasible" / "task_schedule.csv").exists())


if __name__ == "__main__":
    unittest.main()
