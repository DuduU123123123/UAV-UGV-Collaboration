#!/usr/bin/env python3
"""批量运行昌平线最小模型的参数敏感性实验。"""

from __future__ import annotations

import argparse
import copy
import csv
import json
from itertools import product
from pathlib import Path
from time import perf_counter
from typing import Any, Iterable

from changping_min_solver import (
    apply_parameter_overrides,
    build_context,
    load_instance,
    read_planning_window,
    solve,
    write_outputs,
)


ROOT = Path(__file__).resolve().parent


def compact_number(value: int | float) -> str:
    return format(value, "g").replace("-", "m").replace(".", "p")


def build_experiment_id(index: int, config: dict[str, Any]) -> str:
    return (
        f"e{index:03d}"
        f"_end{compact_number(config['end_time_min'])}"
        f"_b{int(config['spare_batteries']):02d}"
        f"_nv{compact_number(config['nest_speed_kmh'])}"
        f"_uv{compact_number(config['uav_speed_mps'])}"
        f"_en{compact_number(config['uav_endurance_min'])}"
        f"_r{int(config['reserve_soc_pct'])}"
        f"_s{compact_number(config['swap_time_min'])}"
        f"_rev{int(bool(config['allow_reverse']))}"
    )


def build_manifest_row(experiment_id: str, result: dict[str, Any]) -> dict[str, Any]:
    task_result = result["task_result"]
    objective = result["objective"]
    final_state = result["final_state"]
    config = result["run_config"]
    validation = result["validation"]
    return {
        "experiment_id": experiment_id,
        "scenario_id": config["scenario_id"],
        "begin_time_min": config["planning_begin_time_min"],
        "end_time_min": config["planning_end_time_min"],
        "window_length_min": config["planning_window_length_min"],
        "shift_end_min": config["shift_end_min"],
        "time_step_min": config["time_step_min"],
        "deadline_policy": config.get("deadline_policy", "fixed"),
        "spare_battery_sets": config["spare_battery_sets"],
        "nest_speed_kmh": config["nest_speed_kmh"],
        "uav_speed_mps": config["uav_speed_mps"],
        "uav_endurance_min": config["uav_endurance_min"],
        "reserve_soc_pct": config["reserve_soc_pct"],
        "swap_time_min": config["swap_time_min"],
        "allow_reverse": config["allow_reverse"],
        "status": result["status"],
        "feasible": result["feasible"],
        "solution_kind": result["solution_kind"],
        "total_task_count": task_result["total_task_count"],
        "completed_task_count": task_result["completed_task_count"],
        "completion_rate_pct": task_result["completion_rate_pct"],
        "completed_task_ids": task_result["completed_task_ids"],
        "uncompleted_task_ids": task_result["uncompleted_task_ids"],
        "uav_task_mapping": [
            f"{row['uav_id']}:{row['task_id']}"
            for row in result["uav_task_assignments"]
        ],
        "finish_time_min": objective["finish_time_min"],
        "elapsed_time_min": objective["elapsed_time_min"],
        "swaps_used": objective["swaps_used"],
        "drone_active_time_min": objective["drone_active_time_min"],
        "vehicle_travel_time_min": objective["vehicle_travel_time_min"],
        "current_soc_pct": final_state["current_soc_pct"],
        "runtime_ms": result["runtime_ms"],
        "expanded_labels": result["search_statistics"]["expanded_labels"],
        "generated_labels": result["search_statistics"]["generated_labels"],
        "validation_passed": validation["passed"],
        "model_constraints_satisfied": validation["model_constraints_satisfied"],
        "validation_check_count": validation["check_count"],
        "validation_violation_count": len(validation["violations"]),
        "output_directory": experiment_id,
    }


def write_experiment_matrix(manifest: list[dict[str, Any]], output_path: Path) -> None:
    if not manifest:
        raise ValueError("实验矩阵为空")
    rows: list[dict[str, Any]] = []
    for manifest_row in manifest:
        row = dict(manifest_row)
        for field in ("completed_task_ids", "uncompleted_task_ids", "uav_task_mapping"):
            row[field] = ";".join(row[field])
        rows.append(row)
    with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_batch_summary(
    manifest: list[dict[str, Any]],
    output_path: Path,
    parameter_grid: dict[str, Any],
    runtime_ms: float,
) -> dict[str, Any]:
    feasible = [row for row in manifest if row["feasible"]]
    best = min(
        feasible,
        key=lambda row: (
            row["finish_time_min"],
            row["swaps_used"],
            row["drone_active_time_min"],
            row["vehicle_travel_time_min"],
        ),
        default=None,
    )
    summary = {
        "model_version": "minimum-runnable-v1.0",
        "total_experiments": len(manifest),
        "feasible_experiments": len(feasible),
        "infeasible_experiments": len(manifest) - len(feasible),
        "validation_passed_experiments": sum(1 for row in manifest if row["validation_passed"]),
        "minimum_feasible_tested_end_time_min": min(
            (row["end_time_min"] for row in feasible),
            default=None,
        ),
        "best_feasible_experiment": best,
        "parameter_grid": parameter_grid,
        "batch_runtime_ms": runtime_ms,
    }
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    return summary


def run_experiment_grid(
    *,
    input_path: Path,
    output_root: Path,
    end_times: Iterable[int],
    battery_counts: Iterable[int],
    nest_speeds: Iterable[float],
    uav_speeds: Iterable[float],
    endurance_minutes: Iterable[float],
    reserve_socs: Iterable[int],
    swap_times: Iterable[float],
    reverse_options: Iterable[bool],
    deadline_policy: str,
    max_labels: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    batch_start = perf_counter()
    base_data = load_instance(input_path)
    output_root.mkdir(parents=True, exist_ok=True)
    parameter_grid = {
        "end_times": list(end_times),
        "battery_counts": list(battery_counts),
        "nest_speeds": list(nest_speeds),
        "uav_speeds": list(uav_speeds),
        "endurance_minutes": list(endurance_minutes),
        "reserve_socs": list(reserve_socs),
        "swap_times": list(swap_times),
        "reverse_options": list(reverse_options),
        "deadline_policy": deadline_policy,
    }
    combinations = product(
        parameter_grid["end_times"],
        parameter_grid["battery_counts"],
        parameter_grid["nest_speeds"],
        parameter_grid["uav_speeds"],
        parameter_grid["endurance_minutes"],
        parameter_grid["reserve_socs"],
        parameter_grid["swap_times"],
        parameter_grid["reverse_options"],
    )
    manifest: list[dict[str, Any]] = []
    for index, values in enumerate(combinations, start=1):
        end_time, batteries, nest_speed, uav_speed, endurance, reserve, swap_time, reverse = values
        config = {
            "end_time_min": end_time,
            "spare_batteries": batteries,
            "nest_speed_kmh": nest_speed,
            "uav_speed_mps": uav_speed,
            "uav_endurance_min": endurance,
            "reserve_soc_pct": reserve,
            "swap_time_min": swap_time,
            "allow_reverse": reverse,
        }
        experiment_id = build_experiment_id(index, config)
        data = copy.deepcopy(base_data)
        apply_parameter_overrides(
            data,
            end_time_min=end_time,
            spare_batteries=batteries,
            nest_speed_kmh=nest_speed,
            uav_speed_mps=uav_speed,
            uav_endurance_min=endurance,
            reserve_soc_pct=reserve,
            swap_time_min=swap_time,
            deadline_policy=deadline_policy,
        )
        context = build_context(data, allow_reverse=reverse)
        result = solve(context, max_labels=max_labels)
        result["experiment_id"] = experiment_id
        result["run_config"]["deadline_policy"] = deadline_policy
        result["run_config"]["requested_experiment_parameters"] = config
        if not result["validation"]["passed"]:
            raise RuntimeError(
                f"实验{experiment_id}未通过自动校验: {result['validation']['violations']}"
            )
        experiment_dir = output_root / experiment_id
        write_outputs(result, experiment_dir)
        with (experiment_dir / "effective_instance.json").open("w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
        manifest.append(build_manifest_row(experiment_id, result))

    with (output_root / "run_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
    write_experiment_matrix(manifest, output_root / "experiment_matrix.csv")
    batch_runtime_ms = round((perf_counter() - batch_start) * 1000, 3)
    summary = write_batch_summary(
        manifest,
        output_root / "batch_summary.json",
        parameter_grid,
        batch_runtime_ms,
    )
    return manifest, summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="昌平线最小模型批量参数实验")
    parser.add_argument("--input", type=Path, default=ROOT / "data" / "changping_min_instance.json")
    parser.add_argument("--output-root", type=Path, default=ROOT / "experiments")
    parser.add_argument("--end-times", nargs="+", type=int, default=list(range(120, 151, 5)))
    parser.add_argument("--battery-counts", nargs="+", type=int, default=[2, 3, 4, 5])
    parser.add_argument("--nest-speeds", nargs="+", type=float, default=None)
    parser.add_argument("--uav-speeds", nargs="+", type=float, default=None)
    parser.add_argument("--endurance-minutes", nargs="+", type=float, default=None)
    parser.add_argument("--reserve-socs", nargs="+", type=int, default=None)
    parser.add_argument("--swap-times", nargs="+", type=float, default=None)
    parser.add_argument("--include-reverse", action="store_true", help="同时运行不反向和允许反向两组场景")
    parser.add_argument(
        "--deadline-policy",
        choices=("fixed", "linked", "clip"),
        default="linked",
        help="EndT变化时任务截止时间处理策略",
    )
    parser.add_argument("--max-labels", type=int, default=500_000)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    base_data = load_instance(args.input)
    _, _, _ = read_planning_window(base_data["parameters"])
    nest = base_data["resources"]["mobile_nests"][0]
    uav = base_data["resources"]["uavs"][0]
    reverse_options = [False, True] if args.include_reverse else [False]
    manifest, summary = run_experiment_grid(
        input_path=args.input,
        output_root=args.output_root,
        end_times=args.end_times,
        battery_counts=args.battery_counts,
        nest_speeds=args.nest_speeds or [float(nest["speed_kmh"])],
        uav_speeds=args.uav_speeds or [float(uav["operational_speed_mps"])],
        endurance_minutes=args.endurance_minutes or [float(uav["usable_endurance_min"])],
        reserve_socs=args.reserve_socs or [int(uav["minimum_reserve_soc_pct"])],
        swap_times=args.swap_times or [float(uav["battery_swap_time_min"])],
        reverse_options=reverse_options,
        deadline_policy=args.deadline_policy,
        max_labels=args.max_labels,
    )
    print(f"完成实验: {len(manifest)}组")
    print(f"全任务可行: {summary['feasible_experiments']}组")
    print(f"自动校验通过: {summary['validation_passed_experiments']}组")
    print(f"已测试场景中的最小可行EndT: {summary['minimum_feasible_tested_end_time_min']}")
    print(f"综合CSV: {(args.output_root / 'experiment_matrix.csv').resolve()}")
    print(f"批量摘要: {(args.output_root / 'batch_summary.json').resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
