#!/usr/bin/env python3
"""昌平线车—机协同巡检模型V1.0的最小可运行实现。

算法采用事件驱动的时空状态网络与标签设置法。状态为：
    (当前时刻, 移动机巢所在站, 无人机SOC, 已完成任务集合, 已换电次数)

仅使用 Python 标准库，适合先验证状态转移、时间窗、能量和会合逻辑。
"""

from __future__ import annotations

import argparse
import csv
import heapq
import json
import math
from dataclasses import dataclass
from itertools import count
from pathlib import Path
from time import perf_counter
from typing import Any, Iterable


@dataclass(frozen=True, slots=True)
class State:
    time_min: int
    station_index: int
    soc_pct: int
    completed_mask: int
    swaps_used: int


@dataclass(slots=True)
class Context:
    data: dict[str, Any]
    stations: list[dict[str, Any]]
    tasks: list[dict[str, Any]]
    task_locations: dict[str, dict[str, Any]]
    station_index: dict[str, int]
    segment_distance: list[int]
    segment_travel_time: list[int]
    start_index: int
    end_index: int
    planning_begin: int
    planning_end: int
    shift_start: int
    shift_end: int
    time_step: int
    soc_step: int
    reserve_soc: int
    initial_soc: int
    spare_batteries: int
    nest_speed_kmh: float
    uav_speed_mps: float
    usable_endurance_min: float
    swap_time_min: int
    allow_reverse: bool
    nest_id: str
    uav_id: str


def ceil_to_step(value: float, step: int) -> int:
    if value <= 0:
        return 0
    return int(math.ceil((value - 1e-12) / step) * step)


def align_time_up(value: float, origin: int, step: int) -> int:
    """将实际时刻向上对齐到以BeginT为原点的离散时间网格。"""
    return origin + ceil_to_step(value - origin, step)


def read_planning_window(parameters: dict[str, Any]) -> tuple[int, int, int]:
    """读取用户输入的BeginT、EndT与Delta，并兼容旧版time_horizon_min。"""
    begin = int(parameters.get("begin_time_min", 0))
    if "end_time_min" in parameters:
        end = int(parameters["end_time_min"])
    elif "time_horizon_min" in parameters:
        end = begin + int(parameters["time_horizon_min"])
    else:
        raise ValueError("parameters必须提供end_time_min；旧数据可暂用time_horizon_min")
    step = int(parameters["time_step_min"])
    return begin, end, step


def load_instance(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    # 轻量场景文件只保存任务子集，避免复制整份基础实例。
    if "base_instance" in data:
        base_path = (path.parent / data["base_instance"]).resolve()
        base_data = load_instance(base_path)
        selected_task_ids = set(data["task_ids"])
        unknown = selected_task_ids.difference(task["task_id"] for task in base_data["tasks"])
        if unknown:
            raise ValueError(f"场景引用了不存在的任务: {sorted(unknown)}")
        base_data["tasks"] = [task for task in base_data["tasks"] if task["task_id"] in selected_task_ids]
        selected_locations = {task["location_id"] for task in base_data["tasks"]}
        base_data["task_locations"] = [
            location for location in base_data["task_locations"] if location["location_id"] in selected_locations
        ]
        base_data.setdefault("metadata", {})["scenario_id"] = data.get("scenario_id", path.stem)
        base_data["metadata"]["scenario_notes"] = data.get("notes", "")
        return base_data
    return data


def apply_planning_end_override(
    data: dict[str, Any],
    new_end_time: int,
    *,
    deadline_policy: str = "fixed",
) -> None:
    """覆盖EndT，并按显式策略处理班次结束与任务截止时间。

    deadline_policy:
      fixed  - 任务时间窗保持用户原始输入；
      linked - 仅将原本等于旧EndT的任务截止时间同步到新EndT；
      clip   - 将超过新EndT的任务截止时间截断到新EndT。
    """
    if deadline_policy not in {"fixed", "linked", "clip"}:
        raise ValueError("deadline_policy必须为fixed、linked或clip")
    parameters = data["parameters"]
    begin_time, old_end_time, time_step = read_planning_window(parameters)
    new_end_time = int(new_end_time)
    if new_end_time <= begin_time or (new_end_time - begin_time) % time_step:
        raise ValueError("新的EndT必须晚于BeginT且与时间步长对齐")

    parameters["begin_time_min"] = begin_time
    parameters["end_time_min"] = new_end_time
    parameters.pop("time_horizon_min", None)
    for nest in data["resources"]["mobile_nests"]:
        if int(nest["shift_end_min"]) == old_end_time:
            nest["shift_end_min"] = new_end_time

    for task in data["tasks"]:
        deadline = float(task["latest_finish_min"])
        if deadline_policy == "linked" and deadline == old_end_time:
            task["latest_finish_min"] = new_end_time
        elif deadline_policy == "clip" and deadline > new_end_time:
            task["latest_finish_min"] = new_end_time


def apply_parameter_overrides(
    data: dict[str, Any],
    *,
    end_time_min: int | None = None,
    time_step_min: int | None = None,
    spare_batteries: int | None = None,
    nest_speed_kmh: float | None = None,
    uav_speed_mps: float | None = None,
    uav_endurance_min: float | None = None,
    reserve_soc_pct: int | None = None,
    swap_time_min: float | None = None,
    deadline_policy: str = "fixed",
) -> None:
    """将命令行或批量实验参数写入一份实例副本。"""
    if time_step_min is not None:
        data["parameters"]["time_step_min"] = int(time_step_min)
    if end_time_min is not None:
        apply_planning_end_override(data, end_time_min, deadline_policy=deadline_policy)

    nest = data["resources"]["mobile_nests"][0]
    uav = data["resources"]["uavs"][0]
    if spare_batteries is not None:
        nest["spare_battery_sets"] = int(spare_batteries)
    if nest_speed_kmh is not None:
        nest["speed_kmh"] = float(nest_speed_kmh)
    if uav_speed_mps is not None:
        uav["operational_speed_mps"] = float(uav_speed_mps)
    if uav_endurance_min is not None:
        uav["usable_endurance_min"] = float(uav_endurance_min)
    if reserve_soc_pct is not None:
        uav["minimum_reserve_soc_pct"] = int(reserve_soc_pct)
    if swap_time_min is not None:
        uav["battery_swap_time_min"] = float(swap_time_min)


def validate_instance(data: dict[str, Any]) -> None:
    required = {
        "parameters",
        "stations",
        "segments",
        "directed_vehicle_arcs",
        "task_locations",
        "tasks",
        "resources",
    }
    missing = required.difference(data)
    if missing:
        raise ValueError(f"缺少顶层字段: {sorted(missing)}")

    stations = sorted(data["stations"], key=lambda row: row["order"])
    if len(stations) < 2:
        raise ValueError("至少需要两个车辆站点")
    if len({row["location_id"] for row in stations}) != len(stations):
        raise ValueError("站点location_id存在重复")
    if any(not row["vehicle_accessible"] for row in stations):
        raise ValueError("stations中存在车辆不可达节点")
    if any(stations[i]["chainage_m"] >= stations[i + 1]["chainage_m"] for i in range(len(stations) - 1)):
        raise ValueError("站点chainage_m必须严格递增")

    segments = data["segments"]
    if len(segments) != len(stations) - 1:
        raise ValueError("首版算法要求线路为连续链，区间数应等于站点数减一")
    for index, segment in enumerate(segments):
        left, right = stations[index], stations[index + 1]
        expected_distance = right["chainage_m"] - left["chainage_m"]
        if segment["from_location_id"] != left["location_id"] or segment["to_location_id"] != right["location_id"]:
            raise ValueError(f"区间{segment['segment_id']}与站点顺序不一致")
        if segment["distance_m"] != expected_distance:
            raise ValueError(f"区间{segment['segment_id']}距离与累计里程不一致")

    directed = data["directed_vehicle_arcs"]
    arc_keys = {(row["from_location_id"], row["to_location_id"], row["distance_m"]) for row in directed}
    for segment in segments:
        forward = (segment["from_location_id"], segment["to_location_id"], segment["distance_m"])
        reverse = (segment["to_location_id"], segment["from_location_id"], segment["distance_m"])
        if forward not in arc_keys or reverse not in arc_keys:
            raise ValueError(f"区间{segment['segment_id']}缺少正向或反向车辆弧")

    parameters = data["parameters"]
    begin_time, end_time, time_step = read_planning_window(parameters)
    if time_step <= 0 or end_time <= begin_time:
        raise ValueError("BeginT、EndT与时间步长必须满足EndT>BeginT且Delta>0")
    if (end_time - begin_time) % time_step:
        raise ValueError("EndT-BeginT必须能被时间步长整除")
    if parameters.get("all_tasks_mandatory") is not True:
        raise ValueError("最小实现要求parameters.all_tasks_mandatory=true")
    if parameters.get("all_resources_mandatory") is not True:
        raise ValueError("最小实现要求parameters.all_resources_mandatory=true")
    if not parameters.get("one_task_per_sortie", True):
        raise ValueError("首版算法仅支持每架次一个任务")

    task_location_ids = {row["location_id"] for row in data["task_locations"]}
    task_ids: set[str] = set()
    for task in data["tasks"]:
        if task["task_id"] in task_ids:
            raise ValueError(f"任务ID重复: {task['task_id']}")
        task_ids.add(task["task_id"])
        if task["location_id"] not in task_location_ids:
            raise ValueError(f"任务{task['task_id']}引用了不存在的任务点")
        if float(task["service_time_min"]) <= 0:
            raise ValueError(f"任务{task['task_id']}服务时间必须为正")
        if task.get("mandatory") is not True:
            raise ValueError(f"任务{task['task_id']}必须显式设置mandatory=true")
        if not (
            begin_time
            <= float(task["earliest_start_min"])
            <= float(task["latest_finish_min"])
            <= end_time
        ):
            raise ValueError(f"任务{task['task_id']}时间窗无效")

    nests = data["resources"].get("mobile_nests", [])
    uavs = data["resources"].get("uavs", [])
    if len(nests) != 1 or len(uavs) != 1:
        raise ValueError("首版算法仅支持1辆移动机巢和1架无人机")
    nest = nests[0]
    uav = uavs[0]
    if nest["start_location_id"] not in {row["location_id"] for row in stations}:
        raise ValueError("移动机巢起点不在stations中")
    if nest["end_location_id"] not in {row["location_id"] for row in stations}:
        raise ValueError("移动机巢终点不在stations中")
    shift_start = int(nest["shift_start_min"])
    shift_end = int(nest["shift_end_min"])
    if not (begin_time <= shift_start < shift_end <= end_time):
        raise ValueError("车辆班次必须位于用户输入的BeginT和EndT之间")
    if (shift_start - begin_time) % time_step or (shift_end - begin_time) % time_step:
        raise ValueError("车辆班次起止时刻必须与离散时间网格对齐")
    if int(nest["uav_capacity"]) < 1:
        raise ValueError("每辆车初始至少需要1个无人机停机位")
    if int(nest["spare_battery_sets"]) < 0:
        raise ValueError("备用电池组数不能为负")
    if float(nest["speed_kmh"]) <= 0:
        raise ValueError("移动机巢速度必须为正")
    if uav.get("assigned_nest_id") != nest["nest_id"]:
        raise ValueError("无人机assigned_nest_id必须与唯一移动机巢nest_id一致")
    if float(uav["operational_speed_mps"]) <= 0 or float(uav["usable_endurance_min"]) <= 0:
        raise ValueError("无人机速度和可用续航时间必须为正")
    if float(uav["battery_swap_time_min"]) <= 0:
        raise ValueError("无人机换电时间必须为正")
    reserve_soc = int(uav["minimum_reserve_soc_pct"])
    initial_soc = int(uav["initial_soc_pct"])
    soc_levels = sorted(int(value) for value in parameters["soc_levels_pct"])
    if not (0 <= reserve_soc < initial_soc <= 100):
        raise ValueError("无人机SOC必须满足0<=安全余量<初始SOC<=100")
    if reserve_soc not in soc_levels or initial_soc not in soc_levels:
        raise ValueError("初始SOC和安全余量必须包含在soc_levels_pct中")
    gaps = {right - left for left, right in zip(soc_levels, soc_levels[1:])}
    if len(soc_levels) < 2 or len(gaps) != 1 or next(iter(gaps)) <= 0:
        raise ValueError("soc_levels_pct必须为至少两个等间距且严格递增的水平")


def build_context(
    data: dict[str, Any],
    *,
    spare_batteries_override: int | None = None,
    allow_reverse: bool = False,
) -> Context:
    validate_instance(data)
    stations = sorted(data["stations"], key=lambda row: row["order"])
    station_index = {row["location_id"]: idx for idx, row in enumerate(stations)}
    tasks = list(data["tasks"])
    task_locations = {row["location_id"]: row for row in data["task_locations"]}
    parameters = data["parameters"]
    nest = data["resources"]["mobile_nests"][0]
    uav = data["resources"]["uavs"][0]
    planning_begin, planning_end, time_step = read_planning_window(parameters)
    nest_speed_kmh = float(nest["speed_kmh"])

    segment_distance = [int(row["distance_m"]) for row in data["segments"]]
    segment_travel_time = [
        ceil_to_step(distance / 1000.0 / nest_speed_kmh * 60.0, time_step)
        for distance in segment_distance
    ]
    soc_levels = sorted(int(value) for value in parameters["soc_levels_pct"])
    soc_step = min(b - a for a, b in zip(soc_levels, soc_levels[1:]))
    spare_batteries = int(nest["spare_battery_sets"])
    if spare_batteries_override is not None:
        if spare_batteries_override < 0:
            raise ValueError("备用电池覆盖值不能为负")
        spare_batteries = spare_batteries_override

    return Context(
        data=data,
        stations=stations,
        tasks=tasks,
        task_locations=task_locations,
        station_index=station_index,
        segment_distance=segment_distance,
        segment_travel_time=segment_travel_time,
        start_index=station_index[nest["start_location_id"]],
        end_index=station_index[nest["end_location_id"]],
        planning_begin=planning_begin,
        planning_end=planning_end,
        shift_start=int(nest["shift_start_min"]),
        shift_end=int(nest["shift_end_min"]),
        time_step=time_step,
        soc_step=soc_step,
        reserve_soc=int(uav["minimum_reserve_soc_pct"]),
        initial_soc=int(uav["initial_soc_pct"]),
        spare_batteries=spare_batteries,
        nest_speed_kmh=nest_speed_kmh,
        uav_speed_mps=float(uav["operational_speed_mps"]),
        usable_endurance_min=float(uav["usable_endurance_min"]),
        swap_time_min=ceil_to_step(float(uav["battery_swap_time_min"]), time_step),
        allow_reverse=allow_reverse,
        nest_id=str(nest["nest_id"]),
        uav_id=str(uav["uav_id"]),
    )


def path_segment_indices(start: int, end: int) -> Iterable[int]:
    if start < end:
        return range(start, end)
    return range(end, start)


def vehicle_path_time(ctx: Context, start: int, end: int) -> int:
    return sum(ctx.segment_travel_time[idx] for idx in path_segment_indices(start, end))


def vehicle_path_distance(ctx: Context, start: int, end: int) -> int:
    return sum(ctx.segment_distance[idx] for idx in path_segment_indices(start, end))


def soc_drop_for_duration(ctx: Context, active_min: int) -> int:
    usable_soc = 100 - ctx.reserve_soc
    raw_drop = active_min / ctx.usable_endurance_min * usable_soc
    return ceil_to_step(raw_drop, ctx.soc_step)


def state_core(state: State) -> tuple[int, int, int, int]:
    return state.station_index, state.soc_pct, state.completed_mask, state.swaps_used


def generate_transitions(ctx: Context, state: State) -> Iterable[tuple[State, dict[str, Any], int, int]]:
    station = ctx.stations[state.station_index]

    # 无人机在车上时，移动机巢可以沿线路移动。默认只向终点方向移动。
    neighbours: list[int] = []
    if state.station_index < len(ctx.stations) - 1:
        neighbours.append(state.station_index + 1)
    if ctx.allow_reverse and state.station_index > 0:
        neighbours.append(state.station_index - 1)
    for next_index in neighbours:
        duration = vehicle_path_time(ctx, state.station_index, next_index)
        end_time = state.time_min + duration
        if end_time <= ctx.shift_end:
            next_station = ctx.stations[next_index]
            next_state = State(end_time, next_index, state.soc_pct, state.completed_mask, state.swaps_used)
            action = {
                "type": "vehicle_move_with_uav_onboard",
                "uav_id": ctx.uav_id,
                "nest_id": ctx.nest_id,
                "start_min": state.time_min,
                "end_min": end_time,
                "nest_from": station["location_id"],
                "nest_to": next_station["location_id"],
                "vehicle_distance_m": vehicle_path_distance(ctx, state.station_index, next_index),
                "soc_before_pct": state.soc_pct,
                "soc_after_pct": state.soc_pct,
                "current_soc_pct": state.soc_pct,
                "swaps_used_before": state.swaps_used,
                "swaps_used_after": state.swaps_used,
            }
            yield next_state, action, 0, duration

    # 换电弧：只记录换电次数，不维护逐时刻库存变量。
    if state.soc_pct < ctx.initial_soc and state.swaps_used < ctx.spare_batteries:
        end_time = state.time_min + ctx.swap_time_min
        if end_time <= ctx.shift_end:
            next_state = State(end_time, state.station_index, ctx.initial_soc, state.completed_mask, state.swaps_used + 1)
            action = {
                "type": "battery_swap",
                "uav_id": ctx.uav_id,
                "nest_id": ctx.nest_id,
                "start_min": state.time_min,
                "end_min": end_time,
                "nest_from": station["location_id"],
                "nest_to": station["location_id"],
                "soc_before_pct": state.soc_pct,
                "soc_after_pct": ctx.initial_soc,
                "current_soc_pct": ctx.initial_soc,
                "swaps_used_before": state.swaps_used,
                "swaps_used_after": state.swaps_used + 1,
            }
            yield next_state, action, 0, 0

    # 联合服务弧：无人机执行一个任务，机巢可同时驶向回收站。
    if ctx.allow_reverse:
        recovery_indices = range(len(ctx.stations))
    else:
        recovery_indices = range(state.station_index, len(ctx.stations))

    launch_chainage = float(station["chainage_m"])
    for task_index, task in enumerate(ctx.tasks):
        task_bit = 1 << task_index
        if state.completed_mask & task_bit:
            continue
        task_location = ctx.task_locations[task["location_id"]]
        task_chainage = float(task_location["chainage_m"])
        outbound_distance = abs(task_chainage - launch_chainage)
        outbound_min = ceil_to_step(outbound_distance / ctx.uav_speed_mps / 60.0, ctx.time_step)
        earliest_service = align_time_up(float(task["earliest_start_min"]), ctx.planning_begin, ctx.time_step)
        service_duration = ceil_to_step(float(task["service_time_min"]), ctx.time_step)
        latest_just_in_time_launch = max(state.time_min, earliest_service - outbound_min)
        launch_times = range(state.time_min, latest_just_in_time_launch + 1, ctx.time_step)

        for recovery_index in recovery_indices:
            recovery_station = ctx.stations[recovery_index]
            recovery_chainage = float(recovery_station["chainage_m"])
            return_distance = abs(task_chainage - recovery_chainage)
            return_min = ceil_to_step(return_distance / ctx.uav_speed_mps / 60.0, ctx.time_step)
            nest_duration = vehicle_path_time(ctx, state.station_index, recovery_index)
            for launch_time in launch_times:
                service_arrival = launch_time + outbound_min
                service_start = max(service_arrival, earliest_service)
                service_end = service_start + service_duration
                if service_end > float(task["latest_finish_min"]):
                    continue

                drone_finish = service_end + return_min
                vehicle_arrival = launch_time + nest_duration
                end_time = max(drone_finish, vehicle_arrival)
                if end_time > ctx.shift_end:
                    continue

                drone_active = end_time - launch_time
                energy_drop = soc_drop_for_duration(ctx, drone_active)
                next_soc = state.soc_pct - energy_drop
                if next_soc < ctx.reserve_soc:
                    continue

                next_state = State(
                    end_time,
                    recovery_index,
                    next_soc,
                    state.completed_mask | task_bit,
                    state.swaps_used,
                )
                action = {
                    "type": "joint_sortie_service",
                    "uav_id": ctx.uav_id,
                    "nest_id": ctx.nest_id,
                    "task_id": task["task_id"],
                    "task_type": task["task_type"],
                    "start_min": state.time_min,
                    "launch_min": launch_time,
                    "end_min": end_time,
                    "service_start_min": service_start,
                    "service_end_min": service_end,
                    "drone_finish_min": drone_finish,
                    "vehicle_arrival_min": vehicle_arrival,
                    "nest_from": station["location_id"],
                    "nest_to": recovery_station["location_id"],
                    "uav_launch": station["location_id"],
                    "uav_recovery": recovery_station["location_id"],
                    "flight_distance_m": round(outbound_distance + return_distance, 3),
                    "vehicle_distance_m": vehicle_path_distance(ctx, state.station_index, recovery_index),
                    "drone_active_min": drone_active,
                    "vehicle_travel_min": nest_duration,
                    "soc_before_pct": state.soc_pct,
                    "soc_drop_pct": energy_drop,
                    "soc_after_pct": next_soc,
                    "current_soc_pct": next_soc,
                    "swaps_used_before": state.swaps_used,
                    "swaps_used_after": state.swaps_used,
                    "prelaunch_wait_min": launch_time - state.time_min,
                    "aerial_wait_before_service_min": service_start - service_arrival,
                    "recovery_hover_min": end_time - drone_finish,
                    "vehicle_wait_after_arrival_min": end_time - vehicle_arrival,
                }
                yield next_state, action, drone_active, nest_duration


def reconstruct_actions(
    parent: dict[State, tuple[State, dict[str, Any]]],
    start: State,
    finish: State,
) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    state = finish
    while state != start:
        previous, action = parent[state]
        actions.append(action)
        state = previous
    actions.reverse()
    return actions


def solve(ctx: Context, max_labels: int = 500_000) -> dict[str, Any]:
    solve_start = perf_counter()
    all_tasks_mask = (1 << len(ctx.tasks)) - 1
    start = State(ctx.shift_start, ctx.start_index, ctx.initial_soc, 0, 0)
    # 目标按完工时间、换电次数、无人机活动时间、车辆运行时间依次最小化。
    start_cost = (ctx.shift_start, 0, 0, 0, 0)
    queue: list[tuple[tuple[int, int, int, int, int], int, State]] = []
    serial = count()
    heapq.heappush(queue, (start_cost, next(serial), start))
    best_by_core: dict[tuple[int, int, int, int], tuple[int, int, int, int, int]] = {state_core(start): start_cost}
    cost_by_state: dict[State, tuple[int, int, int, int, int]] = {start: start_cost}
    parent: dict[State, tuple[State, dict[str, Any]]] = {}
    expanded = 0
    generated = 1
    goal: State | None = None
    best_partial = start
    best_partial_rank = (0, 0, 0, 0, ctx.initial_soc, 0)

    task_weights = [int(task.get("priority_weight", 1)) for task in ctx.tasks]

    while queue:
        cost, _, state = heapq.heappop(queue)
        if cost_by_state.get(state) != cost:
            continue
        expanded += 1
        if expanded > max_labels:
            raise RuntimeError(f"状态标签超过上限{max_labels}，请缩小实例或增大--max-labels")

        completed_count = state.completed_mask.bit_count()
        completed_weight = sum(
            task_weights[index]
            for index in range(len(ctx.tasks))
            if state.completed_mask & (1 << index)
        )
        progress = -abs(ctx.end_index - state.station_index)
        partial_rank = (
            completed_count,
            completed_weight,
            int(state.station_index == ctx.end_index),
            progress,
            -state.time_min,
            state.soc_pct,
        )
        if partial_rank > best_partial_rank:
            best_partial_rank = partial_rank
            best_partial = state

        if state.completed_mask == all_tasks_mask and state.station_index == ctx.end_index:
            goal = state
            break

        for next_state, action, drone_delta, vehicle_delta in generate_transitions(ctx, state):
            next_cost = (
                next_state.time_min,
                next_state.swaps_used,
                cost[2] + drone_delta,
                cost[3] + vehicle_delta,
                cost[4] + 1,
            )
            core = state_core(next_state)
            previous_best = best_by_core.get(core)
            # 相同位置、SOC、任务集合和换电次数下，更早到达一定不劣。
            if previous_best is not None and previous_best <= next_cost:
                continue
            best_by_core[core] = next_cost
            cost_by_state[next_state] = next_cost
            parent[next_state] = (state, action)
            heapq.heappush(queue, (next_cost, next(serial), next_state))
            generated += 1

    finish = goal if goal is not None else best_partial
    actions = reconstruct_actions(parent, start, finish)
    completed_task_ids = [
        task["task_id"]
        for index, task in enumerate(ctx.tasks)
        if finish.completed_mask & (1 << index)
    ]
    uncompleted_task_ids = [
        task["task_id"] for task in ctx.tasks if task["task_id"] not in completed_task_ids
    ]
    total_task_count = len(ctx.tasks)
    completed_task_count = len(completed_task_ids)
    completion_rate_pct = round(completed_task_count / total_task_count * 100, 2) if total_task_count else 100.0
    uav_task_assignments = [
        {
            "uav_id": action["uav_id"],
            "task_id": action["task_id"],
            "task_type": action["task_type"],
            "decision_time_min": action["start_min"],
            "launch_time_min": action["launch_min"],
            "service_start_min": action["service_start_min"],
            "service_end_min": action["service_end_min"],
            "rendezvous_time_min": action["end_min"],
            "launch_station_id": action["uav_launch"],
            "recovery_station_id": action["uav_recovery"],
            "soc_before_pct": action["soc_before_pct"],
            "soc_after_pct": action["soc_after_pct"],
            "swaps_used_after": action["swaps_used_after"],
        }
        for action in actions
        if action["type"] == "joint_sortie_service"
    ]
    finish_cost = cost_by_state[finish]
    solve_runtime_ms = round((perf_counter() - solve_start) * 1000, 3)
    metadata = ctx.data.get("metadata", {})
    scenario_id = metadata.get("scenario_id", metadata.get("instance_id", ""))
    total_vehicle_distance_m = sum(int(action.get("vehicle_distance_m", 0)) for action in actions)
    result = {
        "model_version": "minimum-runnable-v1.0",
        "run_config": {
            "scenario_id": scenario_id,
            "planning_begin_time_min": ctx.planning_begin,
            "planning_end_time_min": ctx.planning_end,
            "planning_window_length_min": ctx.planning_end - ctx.planning_begin,
            "shift_start_min": ctx.shift_start,
            "shift_end_min": ctx.shift_end,
            "time_step_min": ctx.time_step,
            "spare_battery_sets": ctx.spare_batteries,
            "allow_reverse": ctx.allow_reverse,
            "nest_speed_kmh": ctx.nest_speed_kmh,
            "uav_speed_mps": ctx.uav_speed_mps,
            "uav_endurance_min": ctx.usable_endurance_min,
            "reserve_soc_pct": ctx.reserve_soc,
            "swap_time_min": ctx.swap_time_min,
            "total_task_count": total_task_count,
            "uav_ids": [ctx.uav_id],
            "nest_ids": [ctx.nest_id],
        },
        "status": "FEASIBLE_OPTIMAL" if goal is not None else "INFEASIBLE_ALL_TASKS_BEST_PARTIAL_RETURNED",
        "feasible": goal is not None,
        "solution_kind": "FULL" if goal is not None else "BEST_PARTIAL",
        "objective": {
            "finish_time_min": finish.time_min,
            "elapsed_time_min": finish.time_min - ctx.shift_start,
            "swaps_used": finish.swaps_used,
            "drone_active_time_min": finish_cost[2],
            "vehicle_travel_time_min": finish_cost[3],
        },
        "objective_tuple": [finish.time_min, finish.swaps_used, finish_cost[2], finish_cost[3]],
        "completed_task_ids": completed_task_ids,
        "uncompleted_task_ids": uncompleted_task_ids,
        "task_result": {
            "total_task_count": total_task_count,
            "completed_task_count": completed_task_count,
            "completion_rate_pct": completion_rate_pct,
            "completed_task_ids": completed_task_ids,
            "uncompleted_task_ids": uncompleted_task_ids,
        },
        "uav_task_assignments": uav_task_assignments,
        "uav_results": [
            {
                "uav_id": ctx.uav_id,
                "assigned_nest_id": ctx.nest_id,
                "completed_task_count": completed_task_count,
                "completed_task_ids": completed_task_ids,
                "swaps_used": finish.swaps_used,
                "final_soc_pct": finish.soc_pct,
                "active_time_min": finish_cost[2],
            }
        ],
        "vehicle_results": [
            {
                "nest_id": ctx.nest_id,
                "start_station_id": ctx.stations[ctx.start_index]["location_id"],
                "end_station_id": ctx.stations[finish.station_index]["location_id"],
                "travel_time_min": finish_cost[3],
                "travel_distance_m": total_vehicle_distance_m,
            }
        ],
        "final_state": {
            "time_min": finish.time_min,
            "station_id": ctx.stations[finish.station_index]["location_id"],
            "station_name": ctx.stations[finish.station_index]["name"],
            "soc_pct": finish.soc_pct,
            "current_soc_pct": finish.soc_pct,
            "swaps_used": finish.swaps_used,
            "cumulative_swaps_used": finish.swaps_used,
        },
        "runtime_ms": solve_runtime_ms,
        "actions": actions,
        "search_statistics": {
            "expanded_labels": expanded,
            "generated_labels": generated,
            "retained_state_cores": len(best_by_core),
        },
        "effective_parameters": {
            "planning_begin_time_min": ctx.planning_begin,
            "planning_end_time_min": ctx.planning_end,
            "shift_start_min": ctx.shift_start,
            "shift_end_min": ctx.shift_end,
            "spare_battery_sets": ctx.spare_batteries,
            "allow_reverse": ctx.allow_reverse,
            "time_step_min": ctx.time_step,
            "soc_step_pct": ctx.soc_step,
            "all_tasks_mandatory": True,
            "all_resources_mandatory": True,
            "initial_pairing": {"uav_id": ctx.uav_id, "nest_id": ctx.nest_id},
            "objective_priority": [
                "finish_time_min",
                "swaps_used",
                "drone_active_time_min",
                "vehicle_travel_time_min",
            ],
        },
    }
    result["validation"] = validate_solution(ctx, result)
    return result


def validate_solution(ctx: Context, result: dict[str, Any]) -> dict[str, Any]:
    """独立重放动作序列，逐项核对最小模型的核心约束与目标值。"""
    checks = {
        "initial_pairing": True,
        "time_continuity": True,
        "planning_and_shift_window": True,
        "vehicle_path_continuity": True,
        "task_time_windows": True,
        "task_unique_coverage": True,
        "uav_energy": True,
        "battery_inventory": True,
        "vehicle_uav_synchronization": True,
        "resource_state_reporting": True,
        "final_rendezvous": True,
        "objective_recalculation": True,
        "detailed_output_consistency": True,
    }
    violations: list[dict[str, str]] = []

    def fail(check: str, message: str) -> None:
        checks[check] = False
        violations.append({"constraint": check, "message": message})

    nest = ctx.data["resources"]["mobile_nests"][0]
    uav = ctx.data["resources"]["uavs"][0]
    if uav.get("assigned_nest_id") != nest.get("nest_id") or int(nest.get("uav_capacity", 0)) < 1:
        fail("initial_pairing", "初始车机配对或停机位容量不满足一车一机要求")

    current_time = ctx.shift_start
    current_station = ctx.start_index
    current_soc = ctx.initial_soc
    swaps_used = 0
    served: list[str] = []
    drone_active_total = 0
    vehicle_travel_total = 0
    task_by_id = {task["task_id"]: task for task in ctx.tasks}

    for step, action in enumerate(result.get("actions", []), start=1):
        action_type = action.get("type")
        start_time = int(action.get("start_min", -1))
        end_time = int(action.get("end_min", -1))
        current_station_id = ctx.stations[current_station]["location_id"]
        if start_time != current_time:
            fail("time_continuity", f"第{step}步开始时刻{start_time}与上一状态{current_time}不连续")
        if action.get("nest_from") != current_station_id:
            fail("vehicle_path_continuity", f"第{step}步车辆起点与上一状态位置不一致")
        if end_time <= start_time:
            fail("time_continuity", f"第{step}步结束时刻必须晚于开始时刻")
        if not (ctx.planning_begin <= start_time <= end_time <= ctx.planning_end):
            fail("planning_and_shift_window", f"第{step}步超出用户输入的规划天窗")
        if not (ctx.shift_start <= start_time <= end_time <= ctx.shift_end):
            fail("planning_and_shift_window", f"第{step}步超出车辆班次时间")
        for label, value in (("开始", start_time), ("结束", end_time)):
            if (value - ctx.planning_begin) % ctx.time_step:
                fail("planning_and_shift_window", f"第{step}步{label}时刻未与时间步长对齐")
        if action.get("uav_id") != ctx.uav_id or action.get("nest_id") != ctx.nest_id:
            fail("resource_state_reporting", f"第{step}步资源编号与初始车机配对不一致")
        if int(action.get("current_soc_pct", -1)) != int(action.get("soc_after_pct", -2)):
            fail("resource_state_reporting", f"第{step}步当前SOC与动作后SOC不一致")
        if int(action.get("swaps_used_before", -1)) != swaps_used:
            fail("resource_state_reporting", f"第{step}步动作前换电次数与累计值不一致")

        if action_type == "vehicle_move_with_uav_onboard":
            destination_id = action.get("nest_to")
            if destination_id not in ctx.station_index:
                fail("vehicle_path_continuity", f"第{step}步车辆终点不存在")
                continue
            destination = ctx.station_index[destination_id]
            if abs(destination - current_station) != 1:
                fail("vehicle_path_continuity", f"第{step}步车辆未沿相邻站点移动")
            if not ctx.allow_reverse and destination < current_station:
                fail("vehicle_path_continuity", f"第{step}步出现未授权的反向行驶")
            expected_duration = vehicle_path_time(ctx, current_station, destination)
            if end_time - start_time != expected_duration:
                fail("vehicle_path_continuity", f"第{step}步车辆行驶时间与路段数据不一致")
            expected_distance = vehicle_path_distance(ctx, current_station, destination)
            if int(action.get("vehicle_distance_m", -1)) != expected_distance:
                fail("vehicle_path_continuity", f"第{step}步车辆行驶距离与路段数据不一致")
            if int(action.get("soc_before_pct", -1)) != current_soc or int(action.get("soc_after_pct", -1)) != current_soc:
                fail("uav_energy", f"第{step}步随车转运期间无人机SOC不应变化")
            vehicle_travel_total += expected_duration
            current_station = destination
            if int(action.get("swaps_used_after", -1)) != swaps_used:
                fail("resource_state_reporting", f"第{step}步随车移动不应改变换电次数")

        elif action_type == "battery_swap":
            if action.get("nest_to") != current_station_id:
                fail("vehicle_path_continuity", f"第{step}步换电期间车辆位置发生变化")
            if end_time - start_time != ctx.swap_time_min:
                fail("time_continuity", f"第{step}步换电时长与输入参数不一致")
            if int(action.get("soc_before_pct", -1)) != current_soc:
                fail("uav_energy", f"第{step}步换电前SOC与上一状态不一致")
            swaps_used += 1
            if int(action.get("swaps_used_after", -1)) != swaps_used:
                fail("resource_state_reporting", f"第{step}步换电后的累计次数不一致")
            if swaps_used > ctx.spare_batteries:
                fail("battery_inventory", f"第{step}步累计换电次数超过备用电池数")
            current_soc = ctx.initial_soc
            if int(action.get("soc_after_pct", -1)) != current_soc:
                fail("uav_energy", f"第{step}步换电后SOC未恢复至初始值")

        elif action_type == "joint_sortie_service":
            task_id = action.get("task_id")
            if task_id not in task_by_id:
                fail("task_unique_coverage", f"第{step}步引用了不存在的任务{task_id}")
                continue
            if task_id in served:
                fail("task_unique_coverage", f"任务{task_id}被重复执行")
            served.append(task_id)
            task = task_by_id[task_id]
            destination_id = action.get("nest_to")
            if destination_id not in ctx.station_index:
                fail("vehicle_path_continuity", f"第{step}步会合站不存在")
                continue
            destination = ctx.station_index[destination_id]
            if not ctx.allow_reverse and destination < current_station:
                fail("vehicle_path_continuity", f"第{step}步联合服务出现未授权的反向行驶")

            launch_time = int(action.get("launch_min", start_time))
            service_start = int(action.get("service_start_min", -1))
            service_end = int(action.get("service_end_min", -1))
            launch_chainage = float(ctx.stations[current_station]["chainage_m"])
            task_chainage = float(ctx.task_locations[task["location_id"]]["chainage_m"])
            recovery_chainage = float(ctx.stations[destination]["chainage_m"])
            outbound_min = ceil_to_step(abs(task_chainage - launch_chainage) / ctx.uav_speed_mps / 60.0, ctx.time_step)
            return_min = ceil_to_step(abs(task_chainage - recovery_chainage) / ctx.uav_speed_mps / 60.0, ctx.time_step)
            service_duration = ceil_to_step(float(task["service_time_min"]), ctx.time_step)
            if not (start_time <= launch_time <= service_start):
                fail("vehicle_uav_synchronization", f"第{step}步放飞时刻不在有效区间")
            if service_start < launch_time + outbound_min:
                fail("vehicle_uav_synchronization", f"第{step}步无人机未完成去程飞行即开始任务")
            if service_end - service_start != service_duration:
                fail("task_time_windows", f"第{step}步任务离散服务时长不正确")
            if service_start < float(task["earliest_start_min"]) or service_end > float(task["latest_finish_min"]):
                fail("task_time_windows", f"任务{task_id}违反输入时间窗")

            expected_drone_finish = service_end + return_min
            expected_vehicle_duration = vehicle_path_time(ctx, current_station, destination)
            expected_vehicle_arrival = launch_time + expected_vehicle_duration
            expected_end = max(expected_drone_finish, expected_vehicle_arrival)
            if end_time != expected_end:
                fail("vehicle_uav_synchronization", f"第{step}步车机最终会合时刻计算不一致")
            if action.get("uav_launch") != current_station_id or action.get("uav_recovery") != destination_id:
                fail("vehicle_uav_synchronization", f"第{step}步放飞或回收位置与车辆路径不一致")
            if int(action.get("drone_finish_min", -1)) != expected_drone_finish:
                fail("vehicle_uav_synchronization", f"第{step}步无人机到达回收点时刻不一致")
            if int(action.get("vehicle_arrival_min", -1)) != expected_vehicle_arrival:
                fail("vehicle_uav_synchronization", f"第{step}步车辆到达会合站时刻不一致")

            drone_active = end_time - launch_time
            expected_drop = soc_drop_for_duration(ctx, drone_active)
            expected_soc = current_soc - expected_drop
            if int(action.get("soc_before_pct", -1)) != current_soc:
                fail("uav_energy", f"第{step}步起飞前SOC与上一状态不一致")
            if int(action.get("soc_drop_pct", -1)) != expected_drop or int(action.get("soc_after_pct", -1)) != expected_soc:
                fail("uav_energy", f"第{step}步无人机能耗递推不一致")
            if expected_soc < ctx.reserve_soc:
                fail("uav_energy", f"第{step}步无人机SOC低于安全余量")
            current_soc = expected_soc
            drone_active_total += drone_active
            vehicle_travel_total += expected_vehicle_duration
            current_station = destination
            if int(action.get("swaps_used_after", -1)) != swaps_used:
                fail("resource_state_reporting", f"第{step}步联合服务不应改变换电次数")

        else:
            fail("time_continuity", f"第{step}步动作类型{action_type!r}无法识别")

        current_time = end_time

    required_tasks = {task["task_id"] for task in ctx.tasks}
    served_set = set(served)
    if served_set != required_tasks or len(served) != len(served_set):
        missing = sorted(required_tasks - served_set)
        fail("task_unique_coverage", f"未满足全部任务唯一覆盖，缺失任务: {missing}")
    if set(result.get("completed_task_ids", [])) != served_set:
        fail("task_unique_coverage", "结果汇总中的已完成任务与动作序列不一致")
    if current_station != ctx.end_index:
        fail("final_rendezvous", "动作序列未在指定车辆终点完成最终会合")

    objective = result.get("objective", {})
    expected_objective = {
        "finish_time_min": current_time,
        "elapsed_time_min": current_time - ctx.shift_start,
        "swaps_used": swaps_used,
        "drone_active_time_min": drone_active_total,
        "vehicle_travel_time_min": vehicle_travel_total,
    }
    for name, expected in expected_objective.items():
        if int(objective.get(name, -1)) != expected:
            fail("objective_recalculation", f"目标{name}应为{expected}，输出值不一致")

    task_result = result.get("task_result", {})
    if int(task_result.get("total_task_count", -1)) != len(ctx.tasks):
        fail("detailed_output_consistency", "任务汇总中的总任务数不一致")
    if int(task_result.get("completed_task_count", -1)) != len(served_set):
        fail("detailed_output_consistency", "任务汇总中的完成任务数不一致")
    assignment_pairs = [
        (row.get("uav_id"), row.get("task_id"))
        for row in result.get("uav_task_assignments", [])
    ]
    expected_pairs = [(ctx.uav_id, task_id) for task_id in served]
    if assignment_pairs != expected_pairs:
        fail("detailed_output_consistency", "无人机—任务映射与动作序列不一致")
    if float(result.get("runtime_ms", -1)) < 0:
        fail("detailed_output_consistency", "求解耗时不能为负")
    run_config = result.get("run_config", {})
    if (
        int(run_config.get("planning_begin_time_min", -1)) != ctx.planning_begin
        or int(run_config.get("planning_end_time_min", -1)) != ctx.planning_end
        or int(run_config.get("shift_end_min", -1)) != ctx.shift_end
    ):
        fail("detailed_output_consistency", "运行参数汇总与实际求解上下文不一致")

    path_checks = [
        name
        for name in checks
        if name not in {"task_unique_coverage", "final_rendezvous"}
    ]
    model_constraints_satisfied = all(checks.values())
    reported_feasible_consistent = bool(result.get("feasible")) == model_constraints_satisfied
    if not reported_feasible_consistent:
        violations.append({"constraint": "reported_status", "message": "求解状态与约束重放结果不一致"})
    execution_violations = [
        row
        for row in violations
        if row["constraint"] not in {"task_unique_coverage", "final_rendezvous"}
    ]
    validation_passed = all(checks[name] for name in path_checks) and reported_feasible_consistent
    return {
        "passed": validation_passed,
        "check_count": len(checks),
        "valid_executed_path": all(checks[name] for name in path_checks),
        "model_constraints_satisfied": model_constraints_satisfied,
        "reported_feasible_consistent": reported_feasible_consistent,
        "checks": checks,
        "recalculated_objective": expected_objective,
        "violations": execution_violations,
        "model_violations": violations,
    }


def find_minimum_spares(data: dict[str, Any], start_value: int, maximum: int, allow_reverse: bool) -> dict[str, Any]:
    trials: list[dict[str, Any]] = []
    for spare_count in range(start_value, maximum + 1):
        trial_context = build_context(
            data,
            spare_batteries_override=spare_count,
            allow_reverse=allow_reverse,
        )
        trial_result = solve(trial_context)
        trials.append(
            {
                "spare_battery_sets": spare_count,
                "feasible": trial_result["feasible"],
                "completed_task_count": len(trial_result["completed_task_ids"]),
                "finish_time_min": trial_result["objective"]["finish_time_min"],
            }
        )
        if trial_result["feasible"]:
            return {"minimum_feasible_spare_battery_sets": spare_count, "trials": trials}
    return {"minimum_feasible_spare_battery_sets": None, "trials": trials}


def write_outputs(result: dict[str, Any], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "summary.json"
    timeline_path = output_dir / "timeline.csv"
    with summary_path.open("w", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)

    fieldnames = [
        "step",
        "type",
        "uav_id",
        "nest_id",
        "start_min",
        "launch_min",
        "end_min",
        "duration_min",
        "nest_from",
        "nest_to",
        "task_id",
        "task_type",
        "uav_launch",
        "uav_recovery",
        "service_start_min",
        "service_end_min",
        "drone_finish_min",
        "vehicle_arrival_min",
        "flight_distance_m",
        "vehicle_distance_m",
        "drone_active_min",
        "vehicle_travel_min",
        "soc_before_pct",
        "soc_drop_pct",
        "soc_after_pct",
        "current_soc_pct",
        "swaps_used_before",
        "swaps_used_after",
        "prelaunch_wait_min",
        "aerial_wait_before_service_min",
        "recovery_hover_min",
        "vehicle_wait_after_arrival_min",
        "details_json",
    ]
    with timeline_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for index, action in enumerate(result["actions"], start=1):
            writer.writerow(
                {
                    "step": index,
                    "type": action.get("type", ""),
                    "uav_id": action.get("uav_id", ""),
                    "nest_id": action.get("nest_id", ""),
                    "start_min": action.get("start_min", ""),
                    "launch_min": action.get("launch_min", ""),
                    "end_min": action.get("end_min", ""),
                    "duration_min": action.get("end_min", 0) - action.get("start_min", 0),
                    "nest_from": action.get("nest_from", ""),
                    "nest_to": action.get("nest_to", ""),
                    "task_id": action.get("task_id", ""),
                    "task_type": action.get("task_type", ""),
                    "uav_launch": action.get("uav_launch", ""),
                    "uav_recovery": action.get("uav_recovery", ""),
                    "service_start_min": action.get("service_start_min", ""),
                    "service_end_min": action.get("service_end_min", ""),
                    "drone_finish_min": action.get("drone_finish_min", ""),
                    "vehicle_arrival_min": action.get("vehicle_arrival_min", ""),
                    "flight_distance_m": action.get("flight_distance_m", ""),
                    "vehicle_distance_m": action.get("vehicle_distance_m", ""),
                    "drone_active_min": action.get("drone_active_min", ""),
                    "vehicle_travel_min": action.get("vehicle_travel_min", ""),
                    "soc_before_pct": action.get("soc_before_pct", ""),
                    "soc_drop_pct": action.get("soc_drop_pct", ""),
                    "soc_after_pct": action.get("soc_after_pct", ""),
                    "current_soc_pct": action.get("current_soc_pct", ""),
                    "swaps_used_before": action.get("swaps_used_before", ""),
                    "swaps_used_after": action.get("swaps_used_after", ""),
                    "prelaunch_wait_min": action.get("prelaunch_wait_min", ""),
                    "aerial_wait_before_service_min": action.get("aerial_wait_before_service_min", ""),
                    "recovery_hover_min": action.get("recovery_hover_min", ""),
                    "vehicle_wait_after_arrival_min": action.get("vehicle_wait_after_arrival_min", ""),
                    "details_json": json.dumps(action, ensure_ascii=False, separators=(",", ":")),
                }
            )


def parse_args() -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="昌平线车—机协同巡检最小实例基准求解器")
    parser.add_argument(
        "--input",
        type=Path,
        default=script_dir / "data" / "changping_feasible_demo.json",
        help="实例JSON路径",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=script_dir / "results",
        help="结果目录",
    )
    parser.add_argument("--spare-batteries", type=int, default=None, help="覆盖数据中的备用电池组数")
    parser.add_argument("--end-time-min", type=int, default=None, help="覆盖规划结束时刻EndT")
    parser.add_argument("--time-step-min", type=int, default=None, help="覆盖离散时间步长Delta")
    parser.add_argument("--nest-speed-kmh", type=float, default=None, help="覆盖移动机巢速度")
    parser.add_argument("--uav-speed-mps", type=float, default=None, help="覆盖无人机作业速度")
    parser.add_argument("--uav-endurance-min", type=float, default=None, help="覆盖无人机可用续航时间")
    parser.add_argument("--reserve-soc-pct", type=int, default=None, help="覆盖无人机安全SOC下限，须属于SOC网格")
    parser.add_argument("--swap-time-min", type=float, default=None, help="覆盖单次换电时间")
    parser.add_argument(
        "--deadline-policy",
        choices=("fixed", "linked", "clip"),
        default="fixed",
        help="修改EndT时任务截止时间的处理策略；默认保持用户输入不变",
    )
    parser.add_argument("--allow-reverse", action="store_true", help="允许移动机巢反向运行")
    parser.add_argument("--diagnose-max-spares", type=int, default=6, help="无解时将备用电池敏感性检查到该数值")
    parser.add_argument("--max-labels", type=int, default=500_000, help="最大状态标签数")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    data = load_instance(args.input)
    apply_parameter_overrides(
        data,
        end_time_min=args.end_time_min,
        time_step_min=args.time_step_min,
        spare_batteries=args.spare_batteries,
        nest_speed_kmh=args.nest_speed_kmh,
        uav_speed_mps=args.uav_speed_mps,
        uav_endurance_min=args.uav_endurance_min,
        reserve_soc_pct=args.reserve_soc_pct,
        swap_time_min=args.swap_time_min,
        deadline_policy=args.deadline_policy,
    )
    context = build_context(
        data,
        allow_reverse=args.allow_reverse,
    )
    result = solve(context, max_labels=args.max_labels)
    if not result["feasible"] and args.diagnose_max_spares >= context.spare_batteries:
        result["battery_sensitivity"] = find_minimum_spares(
            data,
            context.spare_batteries,
            args.diagnose_max_spares,
            args.allow_reverse,
        )
    write_outputs(result, args.output_dir)

    print(f"状态: {result['status']}")
    print(f"完成任务: {len(result['completed_task_ids'])}/{len(context.tasks)}")
    print(f"结束时刻: {result['objective']['finish_time_min']} min")
    print(f"作业历时: {result['objective']['elapsed_time_min']} min")
    print(f"换电次数: {result['objective']['swaps_used']}")
    print(f"求解耗时: {result['runtime_ms']} ms")
    print(f"自动校验: {'通过' if result['validation']['passed'] else '失败'}")
    print(f"结果目录: {args.output_dir.resolve()}")
    if not result["feasible"]:
        sensitivity = result.get("battery_sensitivity", {})
        minimum = sensitivity.get("minimum_feasible_spare_battery_sets")
        if minimum is not None:
            print(f"诊断: 在其他参数不变时，至少需要{minimum}组备用电池才能覆盖全部任务。")
        else:
            print("诊断: 在当前敏感性范围内仍无全任务可行解。")
    if not result["validation"]["passed"]:
        return 3
    return 0 if result["feasible"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
