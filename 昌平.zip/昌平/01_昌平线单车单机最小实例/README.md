# 昌平线车—机协同巡检最小实验程序

## 1. 程序定位

本目录实现模型 V1.0 的最小闭环，并加入参数覆盖、批量敏感性实验、详细结果和自动校验。当前仍是单车单机特例，不是多车多机一般模型的完整求解器。

当前范围：

- 1 辆移动无人机巢、1 架无人机，所有输入资源必须投入运行；
- 无人机通过 `assigned_nest_id` 初始搭载于唯一移动机巢；
- 线性地铁走廊，默认车辆从起点向终点运行；
- 每架次执行 1 项任务，每项任务必须且只能完成 1 次；
- 支持携机移动、地面等待、放飞、飞行、巡检、并行移动、回收会合和换电；
- 无人机能量采用离散 SOC，换电受备用电池数量限制；
- 目标严格按照“完工时间 → 换电次数 → 无人机活动时间 → 车辆行驶时间”进行字典序优化。

算法采用事件驱动的时空状态网络与标签设置法，仅依赖 Python 标准库。

## 2. 目录

- `changping_min_solver.py`：求解器、参数覆盖和独立结果校验器；
- `run_experiments.py`：全因子批量实验程序；
- `run_case_analysis.py`：第一阶段昌平线算例分析与最短天窗搜索；
- `test_solver.py`：单元测试与小型集成测试；
- `data/changping_feasible_demo.json`：3 任务可行演示场景；
- `data/changping_min_instance.json`：5 任务压力测试实例；
- `results/`：默认单次实验输出；
- `results_full/`：5 任务基准输出；
- `experiments/`：批量实验综合结果和逐场景结果。
- `results_single_pair/`：本次重新运行的第一阶段正式结果。

## 3. 用户输入时间

规划天窗不固定为 120 分钟。新实例在 JSON 中输入：

```json
"parameters": {
  "begin_time_min": 0,
  "end_time_min": 120,
  "time_step_min": 5
}
```

- `begin_time_min`：规划天窗起点 BeginT；
- `end_time_min`：规划天窗终点 EndT；
- `time_step_min`：离散时间步长 Δ；
- `shift_start_min`、`shift_end_min`：车辆实际可工作班次；
- `earliest_start_min`、`latest_finish_min`：各任务的用户输入时间窗。

行驶、飞行、巡检和换电持续时间均按 Δ 向上取整。程序兼容旧版 `time_horizon_min`，但新数据应使用 BeginT 和 EndT。

## 4. 单次实验与调参

运行默认可行实例：

```powershell
python changping_min_solver.py
```

运行完整 5 任务实例：

```powershell
python changping_min_solver.py --input data/changping_min_instance.json --output-dir results_full
```

可覆盖的参数包括：

- `--end-time-min`：EndT；
- `--time-step-min`：Δ；
- `--spare-batteries`：备用电池组数；
- `--nest-speed-kmh`：移动机巢速度；
- `--uav-speed-mps`：无人机速度；
- `--uav-endurance-min`：无人机可用续航；
- `--reserve-soc-pct`：安全 SOC 下限，须属于输入 SOC 网格；
- `--swap-time-min`：换电时间；
- `--allow-reverse`：允许车辆反向行驶。

示例：

```powershell
python changping_min_solver.py `
  --input data/changping_min_instance.json `
  --end-time-min 135 `
  --deadline-policy linked `
  --spare-batteries 4 `
  --output-dir results_end135_b04
```

修改 EndT 时必须明确任务截止时间策略：

- `fixed`：任务时间窗保持用户输入不变，也是单次运行默认值；
- `linked`：仅同步调整原本等于旧 EndT 的任务截止时间；
- `clip`：将超过新 EndT 的任务截止时间截断至新 EndT。

## 5. 批量实验

默认运行 EndT 为 120～150 分钟、间隔 5 分钟，以及备用电池 2～5 组的 28 个组合：

```powershell
python run_experiments.py
```

默认批量实验使用 `linked` 截止时间策略，并在输出中明确记录。可自行指定任意参数网格：

```powershell
python run_experiments.py `
  --end-times 120 125 130 135 `
  --battery-counts 2 3 4 `
  --uav-speeds 3 4 `
  --endurance-minutes 35 45 `
  --output-root experiments_custom
```

还可以使用 `--nest-speeds`、`--reserve-socs`、`--swap-times` 和 `--include-reverse`。程序对输入列表执行全因子组合，因此运行前应留意组合总数。

批量输出：

- `experiment_matrix.csv`：一行一个实验，可直接用于 Excel、统计和绘图；
- `run_manifest.json`：保留数组字段的机器可读综合结果；
- `batch_summary.json`：实验数、可行数、已测试场景中的最小可行 EndT 和最优可行方案；
- `e.../summary.json`：单个场景的完整结果与校验信息；
- `e.../timeline.csv`：单个场景的逐动作时间线。

## 6. 第一阶段一键算例分析

运行：

```powershell
python run_case_analysis.py
```

程序保持单车单机和单架次单任务设定，先执行原始 120 分钟、2 组备用电池配置，再按 5 分钟步长搜索 EndT=120～180、备用电池 2～5 组的组合。搜索采用明确记录的 `linked` 截止时间策略，不会覆盖原始实例文件。

主要输出位于 `case_analysis/`：

- `case_analysis_report.md`：可直接用于报告初稿的中文算例分析；
- `case_analysis_summary.json`：基准、搜索边界、入选方案和验证结果；
- `selected_minimum_feasible/effective_instance.json`：入选方案的完整有效配置；
- `selected_minimum_feasible/task_schedule.csv`：每项任务的开始、结束和回收时刻；
- `selected_minimum_feasible/timeline.csv`：完整车机运行时间线；
- `selected_minimum_feasible/validation_checks.csv`：逐项正确性验证结果；
- `grid/`：全部参数组合的单项结果和汇总表。

## 7. 详细输出与自动验证

每次求解均输出：

- 实际生效的全部参数；
- 可行性、任务完成率和未完成任务；
- 无人机—任务映射；
- 系统完工时刻、换电次数、无人机活动时间和车辆行驶时间；
- 车辆行驶距离、无人机最终 SOC、搜索标签数和求解耗时；
- 放飞、服务、车辆到达、无人机到达和最终会合时刻；
- 地面等待、空中等待、回收点悬停和车辆等待；
- 每一步动作前后的 SOC 与累计换电次数。

校验器会独立重放动作序列，检查初始配对、时间连续性、规划天窗、车辆班次、路径、任务时间窗、唯一覆盖、SOC、备用电池、车机会合、终点及四项目标重算。

- `validation.passed=true`：程序输出在结构、状态和数值上自洽；
- `validation.model_constraints_satisfied=true`：全部任务和终点等完整模型约束均满足；
- 不可行场景可以返回通过结构校验的 `BEST_PARTIAL`，但其 `model_constraints_satisfied` 仍为 `false`。

## 8. 测试

```powershell
python -m unittest -v
```

测试覆盖正常可行解、不可行部分路径、BeginT 非零、车辆班次截止、初始车机配对、时间离散化、地面等待、篡改结果检测、参数覆盖和批量实验输出。

程序退出码：

- `0`：完整可行解且自动校验通过；
- `2`：全任务不可行，但返回的部分路径通过自动校验；
- `3`：输出未通过自动校验，应视为程序错误。

## 9. 当前边界

下一阶段才加入多车多机状态、显式配对决策变量、车辆能量、服务位竞争、任务方向选择和多任务架次。当前实验结论只适用于单车单机、单架次单任务的离散状态网络。
