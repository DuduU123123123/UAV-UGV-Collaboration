#!/usr/bin/env python3
"""一键运行昌平线第一阶段最小算例并生成可复核的算例分析。"""

from __future__ import annotations

import argparse
import csv
import json
import shutil
from pathlib import Path
from time import perf_counter
from typing import Any

from changping_min_solver import build_context, load_instance, read_planning_window, solve, write_outputs
from run_experiments import run_experiment_grid


ROOT = Path(__file__).resolve().parent


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"不能写入空表: {path.name}")
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def first_feasible_by_battery(manifest: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    battery_values = sorted({int(row["spare_battery_sets"]) for row in manifest})
    for batteries in battery_values:
        candidates = sorted(
            (
                row
                for row in manifest
                if int(row["spare_battery_sets"]) == batteries and row["feasible"]
            ),
            key=lambda row: int(row["window_length_min"]),
        )
        first = candidates[0] if candidates else None
        rows.append(
            {
                "spare_battery_sets": batteries,
                "minimum_feasible_tested_end_time_min": (
                    first["end_time_min"] if first else None
                ),
                "minimum_feasible_tested_window_min": (
                    first["window_length_min"] if first else None
                ),
                "feasible_within_search_range": first is not None,
            }
        )
    return rows


def select_minimum_window_solution(manifest: list[dict[str, Any]]) -> dict[str, Any] | None:
    feasible = [row for row in manifest if row["feasible"]]
    return min(
        feasible,
        key=lambda row: (
            int(row["window_length_min"]),
            int(row["spare_battery_sets"]),
            int(row["finish_time_min"]),
            int(row["swaps_used"]),
            int(row["drone_active_time_min"]),
            int(row["vehicle_travel_time_min"]),
        ),
        default=None,
    )


def make_task_schedule(
    selected_result: dict[str, Any],
    effective_instance: dict[str, Any],
) -> list[dict[str, Any]]:
    task_by_id = {task["task_id"]: task for task in effective_instance["tasks"]}
    schedule: list[dict[str, Any]] = []
    for assignment in selected_result["uav_task_assignments"]:
        task = task_by_id[assignment["task_id"]]
        schedule.append(
            {
                "task_id": assignment["task_id"],
                "task_type": assignment["task_type"],
                "uav_id": assignment["uav_id"],
                "launch_station_id": assignment["launch_station_id"],
                "recovery_station_id": assignment["recovery_station_id"],
                "earliest_start_min": task["earliest_start_min"],
                "latest_finish_min": task["latest_finish_min"],
                "service_start_min": assignment["service_start_min"],
                "service_end_min": assignment["service_end_min"],
                "rendezvous_time_min": assignment["rendezvous_time_min"],
                "soc_before_pct": assignment["soc_before_pct"],
                "soc_after_pct": assignment["soc_after_pct"],
            }
        )
    return schedule


def make_validation_rows(validation: dict[str, Any]) -> list[dict[str, Any]]:
    name_map = {
        "initial_pairing": "初始车机配对有效",
        "time_continuity": "动作时间连续",
        "planning_and_shift_window": "规划天窗和车辆班次",
        "vehicle_path_continuity": "无人车路径连续",
        "task_time_windows": "任务时间窗",
        "task_unique_coverage": "每项任务恰好完成一次",
        "uav_energy": "无人机SOC不低于安全下限",
        "battery_inventory": "换电不超过备用电池数",
        "vehicle_uav_synchronization": "车机同站同时回收",
        "resource_state_reporting": "逐动作资源状态一致",
        "final_rendezvous": "天窗结束前在终点会合",
        "objective_recalculation": "四项目标重算一致",
        "detailed_output_consistency": "详细输出字段一致",
    }
    return [
        {
            "check_id": key,
            "check_name": name_map.get(key, key),
            "passed": bool(passed),
        }
        for key, passed in validation["checks"].items()
    ]


def write_markdown_report(
    path: Path,
    *,
    instance: dict[str, Any],
    baseline: dict[str, Any],
    selected: dict[str, Any],
    selected_result: dict[str, Any],
    task_schedule: list[dict[str, Any]],
    boundaries: list[dict[str, Any]],
    end_times: list[int],
    total_runtime_ms: float,
) -> None:
    parameters = instance["parameters"]
    objective = selected_result["objective"]
    validation = selected_result["validation"]
    task_lines = [
        "|任务|类型|时间窗|开始|结束|回收|SOC前→后|",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in task_schedule:
        task_lines.append(
            f"|{row['task_id']}|{row['task_type']}|"
            f"[{row['earliest_start_min']}, {row['latest_finish_min']}]|"
            f"{row['service_start_min']}|{row['service_end_min']}|"
            f"{row['rendezvous_time_min']}|"
            f"{row['soc_before_pct']}%→{row['soc_after_pct']}%|"
        )
    boundary_lines = [
        "|备用电池组数|搜索范围内最短可行EndT|结论|",
        "|---:|---:|---|",
    ]
    for row in boundaries:
        end_t = row["minimum_feasible_tested_end_time_min"]
        boundary_lines.append(
            f"|{row['spare_battery_sets']}|"
            f"{end_t if end_t is not None else '—'}|"
            f"{'可行' if row['feasible_within_search_range'] else '范围内不可行'}|"
        )
    checks = "、".join(
        key for key, passed in validation["checks"].items() if passed
    )
    report = f"""# 昌平线车—机协同巡检第一阶段算例分析

## 1. 实例与边界

本算例包含 {len(instance['stations'])} 个站点、{len(instance['tasks'])} 项巡检任务、1 辆移动无人机巢和 1 架无人机。每个架次只执行一项任务，时间窗、巡检时间、车辆与无人机速度、续航、安全 SOC、换电时间和备用电池数均从实例配置读取。原始站间距离来自北京地铁数据，任务与资源参数属于测试性假设。

配置时间步长为 {parameters['time_step_min']} 分钟。最短天窗搜索范围为 EndT={end_times[0]}～{end_times[-1]}，按 {parameters['time_step_min']} 分钟递增；任务截止时间采用 `linked` 规则，因此本结论只代表该明确场景，不能外推为真实运营定值。

## 2. 原始配置运行结果

原始配置为 EndT={baseline['run_config']['planning_end_time_min']} 分钟、备用电池 {baseline['run_config']['spare_battery_sets']} 组。完整模型可行性为 **{'可行' if baseline['feasible'] else '不可行'}**，可完成 {baseline['task_result']['completed_task_count']}/{baseline['task_result']['total_task_count']} 项任务。返回的部分路径通过执行一致性校验，但未满足全部任务约束，因此不能作为完整可行方案。

## 3. 最短可行天窗

在已测试的离散网格中，最短可行规划天窗为 **{selected['window_length_min']} 分钟**（BeginT={selected['begin_time_min']}，EndT={selected['end_time_min']}），需要 **{selected['spare_battery_sets']} 组备用电池**。EndT={int(selected['end_time_min']) - int(parameters['time_step_min'])} 及更短的已测试组合均不可行，因此 {selected['window_length_min']} 分钟是当前 {parameters['time_step_min']} 分钟离散网格上的最短值。

{chr(10).join(boundary_lines)}

## 4. 入选方案指标

- 是否可行：可行，5/5 项任务全部完成；
- 系统完工时间：{objective['finish_time_min']} 分钟；
- 规划开始后的总历时：{objective['elapsed_time_min']} 分钟；
- 换电次数：{objective['swaps_used']} 次；
- 无人机活动时间：{objective['drone_active_time_min']} 分钟；
- 无人车行驶时间：{objective['vehicle_travel_time_min']} 分钟；
- 单次求解时间：{selected_result['runtime_ms']} ms；
- 本次基准与网格分析总耗时：{total_runtime_ms} ms。

## 5. 任务时间安排

{chr(10).join(task_lines)}

完整逐动作车机时间线见 `selected_minimum_feasible/timeline.csv`，可复现实行、放飞、巡检、回收和换电全过程。

## 6. 自动正确性验证

入选方案的 `validation.passed` 与 `model_constraints_satisfied` 均为 true，{validation['check_count']} 类检查全部通过，违规记录为 0。已通过的检查包括：{checks}。

校验器独立重放动作序列并重新计算四项目标值，重算结果为：完工时间 {validation['recalculated_objective']['finish_time_min']}、换电 {validation['recalculated_objective']['swaps_used']}、无人机活动时间 {validation['recalculated_objective']['drone_active_time_min']}、无人车行驶时间 {validation['recalculated_objective']['vehicle_travel_time_min']}，与求解器输出一致。

## 7. 第一阶段结论与下一步

第一阶段最小闭环已经跑通。当前算例表明，原始 120 分钟、2 组备用电池配置无法覆盖全部 5 项任务；在其他给定参数不变、截止时间按 linked 规则调整时，至少需将天窗扩展到 135 分钟并提供 4 组备用电池。

下一步先开展单车单机敏感性分析，分别改变无人机速度、续航、换电时间和车辆速度，观察可行域与四项目标变化；完成这一阶段并解释结果后，再进入多车多机与初始配对变量扩展。
"""
    path.write_text(report, encoding="utf-8")


def run_case_analysis(
    *,
    input_path: Path,
    output_root: Path,
    max_end_time: int,
    max_batteries: int,
    max_labels: int,
) -> dict[str, Any]:
    analysis_start = perf_counter()
    instance = load_instance(input_path)
    begin_time, configured_end, step = read_planning_window(instance["parameters"])
    configured_batteries = int(instance["resources"]["mobile_nests"][0]["spare_battery_sets"])
    if max_end_time < configured_end:
        raise ValueError("max_end_time不能小于配置中的EndT")
    if max_batteries < configured_batteries:
        raise ValueError("max_batteries不能小于配置中的备用电池数")

    output_root.mkdir(parents=True, exist_ok=True)
    baseline_result = solve(build_context(instance), max_labels=max_labels)
    write_outputs(baseline_result, output_root / "baseline_configured")

    end_times = list(range(configured_end, max_end_time + 1, step))
    battery_counts = list(range(configured_batteries, max_batteries + 1))
    nest = instance["resources"]["mobile_nests"][0]
    uav = instance["resources"]["uavs"][0]
    manifest, batch_summary = run_experiment_grid(
        input_path=input_path,
        output_root=output_root / "grid",
        end_times=end_times,
        battery_counts=battery_counts,
        nest_speeds=[float(nest["speed_kmh"])],
        uav_speeds=[float(uav["operational_speed_mps"])],
        endurance_minutes=[float(uav["usable_endurance_min"])],
        reserve_socs=[int(uav["minimum_reserve_soc_pct"])],
        swap_times=[float(uav["battery_swap_time_min"])],
        reverse_options=[False],
        deadline_policy="linked",
        max_labels=max_labels,
    )
    selected = select_minimum_window_solution(manifest)
    if selected is None:
        raise RuntimeError("给定搜索范围内未找到全任务可行方案")

    selected_source = output_root / "grid" / selected["experiment_id"]
    selected_dir = output_root / "selected_minimum_feasible"
    selected_dir.mkdir(parents=True, exist_ok=True)
    for name in ("summary.json", "timeline.csv", "effective_instance.json"):
        shutil.copy2(selected_source / name, selected_dir / name)

    selected_result = json.loads((selected_dir / "summary.json").read_text(encoding="utf-8"))
    effective_instance = json.loads(
        (selected_dir / "effective_instance.json").read_text(encoding="utf-8")
    )
    task_schedule = make_task_schedule(selected_result, effective_instance)
    validation_rows = make_validation_rows(selected_result["validation"])
    boundaries = first_feasible_by_battery(manifest)
    write_csv(selected_dir / "task_schedule.csv", task_schedule)
    write_csv(selected_dir / "validation_checks.csv", validation_rows)

    configured_resource_candidates = [
        row
        for row in manifest
        if int(row["spare_battery_sets"]) == configured_batteries and row["feasible"]
    ]
    total_runtime_ms = round((perf_counter() - analysis_start) * 1000, 3)
    analysis_summary = {
        "analysis_stage": "phase_1_single_ugv_single_uav",
        "instance_id": instance["metadata"]["instance_id"],
        "scale": {
            "station_count": len(instance["stations"]),
            "task_count": len(instance["tasks"]),
            "mobile_nest_count": len(instance["resources"]["mobile_nests"]),
            "uav_count": len(instance["resources"]["uavs"]),
            "one_task_per_sortie": bool(instance["parameters"]["one_task_per_sortie"]),
        },
        "baseline_configured": {
            "end_time_min": configured_end,
            "spare_battery_sets": configured_batteries,
            "feasible": baseline_result["feasible"],
            "completed_task_count": baseline_result["task_result"]["completed_task_count"],
            "total_task_count": baseline_result["task_result"]["total_task_count"],
            "validation_passed": baseline_result["validation"]["passed"],
            "model_constraints_satisfied": baseline_result["validation"][
                "model_constraints_satisfied"
            ],
        },
        "search_definition": {
            "begin_time_min": begin_time,
            "tested_end_times": end_times,
            "tested_battery_counts": battery_counts,
            "deadline_policy": "linked",
            "time_step_min": step,
        },
        "fixed_configured_batteries_minimum_feasible_tested_end_time_min": min(
            (row["end_time_min"] for row in configured_resource_candidates),
            default=None,
        ),
        "minimum_feasible_tested_solution": selected,
        "feasibility_boundary_by_battery": boundaries,
        "selected_task_schedule": task_schedule,
        "selected_validation": selected_result["validation"],
        "total_analysis_runtime_ms": total_runtime_ms,
        "batch_summary": batch_summary,
    }
    (output_root / "case_analysis_summary.json").write_text(
        json.dumps(analysis_summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    write_markdown_report(
        output_root / "case_analysis_report.md",
        instance=instance,
        baseline=baseline_result,
        selected=selected,
        selected_result=selected_result,
        task_schedule=task_schedule,
        boundaries=boundaries,
        end_times=end_times,
        total_runtime_ms=total_runtime_ms,
    )
    return analysis_summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="昌平线第一阶段最小算例分析")
    parser.add_argument("--input", type=Path, default=ROOT / "data" / "changping_min_instance.json")
    parser.add_argument("--output-root", type=Path, default=ROOT / "case_analysis")
    parser.add_argument("--max-end-time", type=int, default=180)
    parser.add_argument("--max-batteries", type=int, default=5)
    parser.add_argument("--max-labels", type=int, default=500_000)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    summary = run_case_analysis(
        input_path=args.input,
        output_root=args.output_root,
        max_end_time=args.max_end_time,
        max_batteries=args.max_batteries,
        max_labels=args.max_labels,
    )
    selected = summary["minimum_feasible_tested_solution"]
    print(f"原始配置可行: {summary['baseline_configured']['feasible']}")
    print(f"离散网格最短可行天窗: {selected['window_length_min']} min")
    print(f"对应备用电池: {selected['spare_battery_sets']}组")
    print(f"完工时间: {selected['finish_time_min']} min")
    print(f"全部验证通过: {summary['selected_validation']['model_constraints_satisfied']}")
    print(f"分析报告: {(args.output_root / 'case_analysis_report.md').resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
