#!/usr/bin/env python3
"""昌平线多车多机扩展：固定初始配对 + 跨车辆任务分配。

本阶段复用已经通过验证的单车单机时空状态网络作为子问题，枚举小规模
任务分配，并按“完工时间、换电、无人机活动、车辆行驶”严格字典序选优。
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
from collections import Counter
from itertools import product
from pathlib import Path
from time import perf_counter
from typing import Any

from single_pair_core import (
    apply_planning_end_override,
    build_context,
    load_instance,
    read_planning_window,
    solve,
    write_outputs,
)


ROOT = Path(__file__).resolve().parent


def build_pair_instance(
    multi_data: dict[str, Any],
    nest: dict[str, Any],
    uav: dict[str, Any],
    assigned_task_ids: tuple[str, ...] | list[str],
) -> dict[str, Any]:
    selected = set(assigned_task_ids)
    data = copy.deepcopy(multi_data)
    data["tasks"] = [task for task in multi_data["tasks"] if task["task_id"] in selected]
    selected_locations = {task["location_id"] for task in data["tasks"]}
    data["task_locations"] = [
        location
        for location in multi_data["task_locations"]
        if location["location_id"] in selected_locations
    ]
    data["resources"] = {
        "mobile_nests": [copy.deepcopy(nest)],
        "uavs": [copy.deepcopy(uav)],
    }
    data["metadata"]["scenario_id"] = (
        f"{multi_data['metadata']['instance_id']}_{nest['nest_id']}_{uav['uav_id']}"
    )
    return data


def validate_multi_instance(data: dict[str, Any]) -> None:
    tasks = data.get("tasks", [])
    nests = data.get("resources", {}).get("mobile_nests", [])
    uavs = data.get("resources", {}).get("uavs", [])
    requirements = data.get("multi_requirements", {})
    if len(nests) < 1 or len(uavs) < 1:
        raise ValueError("资源规模分析至少需要1辆移动机巢和1架无人机")
    if len(nests) != len(uavs):
        raise ValueError("本阶段要求每辆移动机巢恰好初始搭载1架无人机")
    if len({row["nest_id"] for row in nests}) != len(nests):
        raise ValueError("nest_id存在重复")
    if len({row["uav_id"] for row in uavs}) != len(uavs):
        raise ValueError("uav_id存在重复")
    nest_ids = {row["nest_id"] for row in nests}
    pairing = [row["assigned_nest_id"] for row in uavs]
    if set(pairing) != nest_ids or len(set(pairing)) != len(pairing):
        raise ValueError("初始配对g_uv必须使每辆车恰好配对1架无人机")
    if any(int(nest["uav_capacity"]) != 1 for nest in nests):
        raise ValueError("本阶段每辆车的无人机容量必须为1")
    if requirements.get("all_tasks_mandatory") is not True:
        raise ValueError("all_tasks_mandatory必须为true")
    if requirements.get("all_resources_mandatory") is not True:
        raise ValueError("all_resources_mandatory必须为true")
    if requirements.get("one_task_per_sortie") is not True:
        raise ValueError("本阶段仅支持单架次单任务")
    if requirements.get("require_each_uav_at_least_one_task") and len(tasks) < len(uavs):
        raise ValueError("任务数不足，无法保证每架无人机至少执行1项任务")

    uav_by_nest = {uav["assigned_nest_id"]: uav for uav in uavs}
    all_task_ids = tuple(task["task_id"] for task in tasks)
    for nest in nests:
        # 逐配对调用单车单机核心校验网络、时间窗、速度、电池和班次参数。
        pair_data = build_pair_instance(data, nest, uav_by_nest[nest["nest_id"]], all_task_ids)
        build_context(pair_data)


def load_multi_instance(config_path: Path) -> dict[str, Any]:
    with config_path.open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    network_path = (config_path.parent / config["network_task_file"]).resolve()
    data = load_instance(network_path)
    original_metadata = copy.deepcopy(data.get("metadata", {}))
    data["metadata"] = {
        **original_metadata,
        **config["metadata"],
        "network_task_source": str(network_path),
    }
    data["resources"] = copy.deepcopy(config["resources"])
    data["multi_requirements"] = copy.deepcopy(config["requirements"])
    data["objective_priority"] = list(config["objective_priority"])
    data["parameters"]["all_tasks_mandatory"] = bool(
        config["requirements"]["all_tasks_mandatory"]
    )
    data["parameters"]["all_resources_mandatory"] = bool(
        config["requirements"]["all_resources_mandatory"]
    )
    data["parameters"]["one_task_per_sortie"] = bool(
        config["requirements"]["one_task_per_sortie"]
    )
    planning = config["planning"]
    apply_planning_end_override(
        data,
        int(planning["end_time_min"]),
        deadline_policy=planning.get("deadline_policy", "fixed"),
    )
    data["multi_model"] = {
        "planning_deadline_policy": planning.get("deadline_policy", "fixed"),
        "implemented_features": [
            "multiple_mobile_nests",
            "multiple_uavs",
            "fixed_initial_pairing_g_uv",
            "exclusive_task_assignment",
            "one_task_per_sortie",
        ],
        "deferred_features": [
            "single_service_position_competition",
            "ugv_energy_constraint",
            "task_direction_choice",
            "multiple_tasks_per_sortie",
        ],
    }
    validate_multi_instance(data)
    return data


def apply_multi_overrides(
    data: dict[str, Any],
    *,
    end_time_min: int | None = None,
    deadline_policy: str = "fixed",
    spare_batteries: int | None = None,
    nest_speed_kmh: float | None = None,
    uav_speed_mps: float | None = None,
    uav_endurance_min: float | None = None,
    swap_time_min: float | None = None,
) -> None:
    if end_time_min is not None:
        apply_planning_end_override(data, end_time_min, deadline_policy=deadline_policy)
        data["multi_model"]["planning_deadline_policy"] = deadline_policy
    for nest in data["resources"]["mobile_nests"]:
        if spare_batteries is not None:
            nest["spare_battery_sets"] = int(spare_batteries)
        if nest_speed_kmh is not None:
            nest["speed_kmh"] = float(nest_speed_kmh)
    for uav in data["resources"]["uavs"]:
        if uav_speed_mps is not None:
            uav["operational_speed_mps"] = float(uav_speed_mps)
        if uav_endurance_min is not None:
            uav["usable_endurance_min"] = float(uav_endurance_min)
        if swap_time_min is not None:
            uav["battery_swap_time_min"] = float(swap_time_min)
    validate_multi_instance(data)


def initial_pairing_matrix(data: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for uav in data["resources"]["uavs"]:
        for nest in data["resources"]["mobile_nests"]:
            rows.append(
                {
                    "uav_id": uav["uav_id"],
                    "nest_id": nest["nest_id"],
                    "g_uv": int(uav["assigned_nest_id"] == nest["nest_id"]),
                }
            )
    return rows


def validate_multi_solution(data: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    task_ids = [task["task_id"] for task in data["tasks"]]
    assignments = result.get("task_assignments", [])
    pair_solutions = result.get("_pair_solutions", [])
    counts = Counter(row["task_id"] for row in assignments)
    uav_ids = {uav["uav_id"] for uav in data["resources"]["uavs"]}
    nest_ids = {nest["nest_id"] for nest in data["resources"]["mobile_nests"]}
    objective = result.get("objective", {})
    recalculated = {
        "makespan_min": max(
            (pair["objective"]["finish_time_min"] for pair in pair_solutions),
            default=None,
        ),
        "total_swaps": sum(pair["objective"]["swaps_used"] for pair in pair_solutions),
        "total_uav_active_min": sum(
            pair["objective"]["drone_active_time_min"] for pair in pair_solutions
        ),
        "total_vehicle_travel_min": sum(
            pair["objective"]["vehicle_travel_time_min"] for pair in pair_solutions
        ),
    }
    pair_checks = [pair["validation"]["model_constraints_satisfied"] for pair in pair_solutions]
    checks = {
        "initial_pairing_g_uv": all(
            sum(row["g_uv"] for row in initial_pairing_matrix(data) if row["uav_id"] == uav_id)
            == 1
            for uav_id in uav_ids
        )
        and all(
            sum(row["g_uv"] for row in initial_pairing_matrix(data) if row["nest_id"] == nest_id)
            == 1
            for nest_id in nest_ids
        ),
        "all_resources_active": {row["uav_id"] for row in assignments} == uav_ids
        and {row["nest_id"] for row in assignments} == nest_ids,
        "task_exactly_once": set(counts) == set(task_ids)
        and all(counts[task_id] == 1 for task_id in task_ids),
        "pair_subproblem_constraints": len(pair_solutions) == len(uav_ids)
        and all(pair_checks),
        "task_time_windows": all(
            pair["validation"]["checks"]["task_time_windows"] for pair in pair_solutions
        ),
        "uav_energy": all(
            pair["validation"]["checks"]["uav_energy"] for pair in pair_solutions
        ),
        "battery_inventory": all(
            pair["validation"]["checks"]["battery_inventory"] for pair in pair_solutions
        ),
        "vehicle_uav_synchronization": all(
            pair["validation"]["checks"]["vehicle_uav_synchronization"]
            for pair in pair_solutions
        ),
        "terminal_return": all(
            pair["validation"]["checks"]["final_rendezvous"] for pair in pair_solutions
        ),
        "objective_recalculation": objective == recalculated,
        "combined_timeline_resource_ids": all(
            action.get("uav_id") in uav_ids and action.get("nest_id") in nest_ids
            for action in result.get("actions", [])
        ),
    }
    violations = [name for name, passed in checks.items() if not passed]
    return {
        "passed": not violations,
        "model_constraints_satisfied": result.get("feasible", False) and not violations,
        "check_count": len(checks),
        "checks": checks,
        "recalculated_objective": recalculated,
        "violations": violations,
    }


def solve_multi(data: dict[str, Any], *, max_labels: int = 500_000) -> dict[str, Any]:
    validate_multi_instance(data)
    started = perf_counter()
    tasks = list(data["tasks"])
    nests = list(data["resources"]["mobile_nests"])
    uav_by_nest = {
        uav["assigned_nest_id"]: uav for uav in data["resources"]["uavs"]
    }
    pairs = [(nest, uav_by_nest[nest["nest_id"]]) for nest in nests]
    require_active = data["multi_requirements"].get(
        "require_each_uav_at_least_one_task", False
    )
    cache: dict[tuple[int, tuple[str, ...]], dict[str, Any]] = {}
    trials: list[dict[str, Any]] = []
    best_payload: dict[str, Any] | None = None
    candidate_assignments = 0

    for allocation in product(range(len(pairs)), repeat=len(tasks)):
        if require_active and set(allocation) != set(range(len(pairs))):
            continue
        candidate_assignments += 1
        pair_solutions: list[dict[str, Any]] = []
        assignment_text: list[str] = []
        assignment_feasible = True
        for pair_index, (nest, uav) in enumerate(pairs):
            assigned_ids = tuple(
                task["task_id"]
                for task, assigned_pair in zip(tasks, allocation)
                if assigned_pair == pair_index
            )
            assignment_text.extend(f"{task_id}->{uav['uav_id']}" for task_id in assigned_ids)
            cache_key = (pair_index, assigned_ids)
            if cache_key not in cache:
                pair_data = build_pair_instance(data, nest, uav, assigned_ids)
                cache[cache_key] = solve(build_context(pair_data), max_labels=max_labels)
            pair_result = cache[cache_key]
            pair_solutions.append(pair_result)
            if not pair_result["feasible"]:
                assignment_feasible = False

        if assignment_feasible:
            objective = {
                "makespan_min": max(
                    pair["objective"]["finish_time_min"] for pair in pair_solutions
                ),
                "total_swaps": sum(
                    pair["objective"]["swaps_used"] for pair in pair_solutions
                ),
                "total_uav_active_min": sum(
                    pair["objective"]["drone_active_time_min"] for pair in pair_solutions
                ),
                "total_vehicle_travel_min": sum(
                    pair["objective"]["vehicle_travel_time_min"] for pair in pair_solutions
                ),
            }
            objective_tuple = tuple(objective.values())
        else:
            objective = None
            objective_tuple = None
        trials.append(
            {
                "assignment": ";".join(sorted(assignment_text)),
                "feasible": assignment_feasible,
                "makespan_min": objective["makespan_min"] if objective else "",
                "total_swaps": objective["total_swaps"] if objective else "",
                "total_uav_active_min": objective["total_uav_active_min"] if objective else "",
                "total_vehicle_travel_min": (
                    objective["total_vehicle_travel_min"] if objective else ""
                ),
            }
        )
        if not assignment_feasible:
            continue
        if best_payload is None or objective_tuple < best_payload["objective_tuple"]:
            best_payload = {
                "allocation": allocation,
                "pair_solutions": pair_solutions,
                "objective": objective,
                "objective_tuple": objective_tuple,
            }

    begin_time, end_time, step = read_planning_window(data["parameters"])
    if best_payload is None:
        return {
            "model_version": "multi-pair-phase2-v1.0",
            "status": "INFEASIBLE_ALL_ASSIGNMENTS",
            "feasible": False,
            "run_config": {
                "instance_id": data["metadata"]["instance_id"],
                "planning_begin_time_min": begin_time,
                "planning_end_time_min": end_time,
                "time_step_min": step,
                "pair_count": len(pairs),
                "task_count": len(tasks),
            },
            "objective": None,
            "task_assignments": [],
            "actions": [],
            "assignment_trials": trials,
            "search_statistics": {
                "candidate_assignments": candidate_assignments,
                "feasible_assignments": 0,
                "single_pair_subproblems_solved": len(cache),
            },
            "runtime_ms": round((perf_counter() - started) * 1000, 3),
            "validation": {
                "passed": True,
                "model_constraints_satisfied": False,
                "check_count": 0,
                "checks": {},
                "violations": [],
            },
        }

    pair_solutions = best_payload["pair_solutions"]
    task_assignments: list[dict[str, Any]] = []
    actions: list[dict[str, Any]] = []
    pair_results: list[dict[str, Any]] = []
    for pair_index, ((nest, uav), pair_result) in enumerate(zip(pairs, pair_solutions)):
        assigned_ids = [
            task["task_id"]
            for task, allocated_pair in zip(tasks, best_payload["allocation"])
            if allocated_pair == pair_index
        ]
        pair_results.append(
            {
                "nest_id": nest["nest_id"],
                "uav_id": uav["uav_id"],
                "assigned_task_ids": assigned_ids,
                "finish_time_min": pair_result["objective"]["finish_time_min"],
                "swaps_used": pair_result["objective"]["swaps_used"],
                "uav_active_time_min": pair_result["objective"]["drone_active_time_min"],
                "vehicle_travel_time_min": pair_result["objective"][
                    "vehicle_travel_time_min"
                ],
                "runtime_ms": pair_result["runtime_ms"],
                "validation_passed": pair_result["validation"][
                    "model_constraints_satisfied"
                ],
            }
        )
        for assignment in pair_result["uav_task_assignments"]:
            task_assignments.append(
                {
                    **assignment,
                    "nest_id": nest["nest_id"],
                }
            )
        for pair_action_index, action in enumerate(pair_result["actions"], start=1):
            actions.append(
                {
                    **action,
                    "pair_action_index": pair_action_index,
                }
            )
    task_order = {task["task_id"]: index for index, task in enumerate(tasks)}
    task_assignments.sort(key=lambda row: task_order[row["task_id"]])
    actions.sort(
        key=lambda action: (
            action["start_min"],
            action["end_min"],
            action["nest_id"],
            action["pair_action_index"],
        )
    )
    for global_index, action in enumerate(actions, start=1):
        action["global_action_index"] = global_index

    result = {
        "model_version": "multi-pair-phase2-v1.0",
        "status": "FEASIBLE_OPTIMAL_ASSIGNMENT",
        "feasible": True,
        "model_scope": data["multi_model"],
        "run_config": {
            "instance_id": data["metadata"]["instance_id"],
            "planning_begin_time_min": begin_time,
            "planning_end_time_min": end_time,
            "planning_window_length_min": end_time - begin_time,
            "time_step_min": step,
            "pair_count": len(pairs),
            "task_count": len(tasks),
            "deadline_policy": data["multi_model"]["planning_deadline_policy"],
        },
        "initial_pairing_matrix": initial_pairing_matrix(data),
        "objective": best_payload["objective"],
        "objective_tuple": list(best_payload["objective_tuple"]),
        "task_assignments": task_assignments,
        "pair_results": pair_results,
        "actions": actions,
        "assignment_trials": trials,
        "search_statistics": {
            "candidate_assignments": candidate_assignments,
            "feasible_assignments": sum(1 for row in trials if row["feasible"]),
            "single_pair_subproblems_solved": len(cache),
        },
        "runtime_ms": round((perf_counter() - started) * 1000, 3),
        "_pair_solutions": pair_solutions,
    }
    result["validation"] = validate_multi_solution(data, result)
    return result


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_multi_outputs(data: dict[str, Any], result: dict[str, Any], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    serializable = {key: value for key, value in result.items() if not key.startswith("_")}
    (output_dir / "summary.json").write_text(
        json.dumps(serializable, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output_dir / "effective_multi_instance.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_csv(output_dir / "initial_pairing_matrix.csv", result.get("initial_pairing_matrix", []))
    write_csv(output_dir / "task_assignment.csv", result.get("task_assignments", []))
    write_csv(output_dir / "assignment_trials.csv", result.get("assignment_trials", []))
    validation_rows = [
        {"check": name, "passed": passed}
        for name, passed in result.get("validation", {}).get("checks", {}).items()
    ]
    write_csv(output_dir / "validation_checks.csv", validation_rows)

    timeline_rows: list[dict[str, Any]] = []
    for action in result.get("actions", []):
        timeline_rows.append(
            {
                "global_action_index": action["global_action_index"],
                "pair_action_index": action["pair_action_index"],
                "type": action["type"],
                "nest_id": action["nest_id"],
                "uav_id": action["uav_id"],
                "start_min": action["start_min"],
                "launch_min": action.get("launch_min", ""),
                "end_min": action["end_min"],
                "nest_from": action.get("nest_from", ""),
                "nest_to": action.get("nest_to", ""),
                "task_id": action.get("task_id", ""),
                "service_start_min": action.get("service_start_min", ""),
                "service_end_min": action.get("service_end_min", ""),
                "drone_finish_min": action.get("drone_finish_min", ""),
                "vehicle_arrival_min": action.get("vehicle_arrival_min", ""),
                "soc_before_pct": action.get("soc_before_pct", ""),
                "soc_after_pct": action.get("soc_after_pct", ""),
                "swaps_used_before": action.get("swaps_used_before", ""),
                "swaps_used_after": action.get("swaps_used_after", ""),
                "details_json": json.dumps(action, ensure_ascii=False, separators=(",", ":")),
            }
        )
    write_csv(output_dir / "combined_timeline.csv", timeline_rows)

    for pair_result, pair_summary in zip(result.get("_pair_solutions", []), result.get("pair_results", [])):
        pair_dir = output_dir / "pair_results" / (
            f"{pair_summary['nest_id']}_{pair_summary['uav_id']}"
        )
        write_outputs(pair_result, pair_dir)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="昌平线多车多机固定配对与任务分配求解器")
    parser.add_argument(
        "--config",
        type=Path,
        default=ROOT / "data" / "changping_two_pair_config.json",
    )
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results_two_pair")
    parser.add_argument("--end-time-min", type=int, default=None)
    parser.add_argument(
        "--deadline-policy", choices=("fixed", "linked", "clip"), default="fixed"
    )
    parser.add_argument("--spare-batteries", type=int, default=None)
    parser.add_argument("--nest-speed-kmh", type=float, default=None)
    parser.add_argument("--uav-speed-mps", type=float, default=None)
    parser.add_argument("--uav-endurance-min", type=float, default=None)
    parser.add_argument("--swap-time-min", type=float, default=None)
    parser.add_argument("--max-labels", type=int, default=500_000)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    data = load_multi_instance(args.config)
    apply_multi_overrides(
        data,
        end_time_min=args.end_time_min,
        deadline_policy=args.deadline_policy,
        spare_batteries=args.spare_batteries,
        nest_speed_kmh=args.nest_speed_kmh,
        uav_speed_mps=args.uav_speed_mps,
        uav_endurance_min=args.uav_endurance_min,
        swap_time_min=args.swap_time_min,
    )
    result = solve_multi(data, max_labels=args.max_labels)
    write_multi_outputs(data, result, args.output_dir)
    print(f"状态: {result['status']}")
    print(f"任务分配方案数: {result['search_statistics']['candidate_assignments']}")
    print(f"可行分配方案数: {result['search_statistics']['feasible_assignments']}")
    if result["feasible"]:
        objective = result["objective"]
        print(f"系统完工时间: {objective['makespan_min']} min")
        print(f"总换电次数: {objective['total_swaps']}")
        print(f"无人机总活动时间: {objective['total_uav_active_min']} min")
        print(f"无人车总行驶时间: {objective['total_vehicle_travel_min']} min")
        print(f"自动校验: {'通过' if result['validation']['passed'] else '失败'}")
    print(f"总求解时间: {result['runtime_ms']} ms")
    print(f"结果目录: {args.output_dir.resolve()}")
    if not result["validation"]["passed"]:
        return 3
    return 0 if result["feasible"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
