# 昌平线多车多机扩展（第二阶段）

## 当前实现范围

本目录与单车单机程序完全分开。当前只加入既定扩展顺序中的前两项：

1. 多辆移动无人机巢、多架无人机和固定初始配对矩阵 `g_uv`；
2. 多个车机对之间的任务唯一分配。

仍保持每辆车初始搭载1架无人机、每架次执行1项任务、所有资源必须运行且每架无人机至少执行1项任务。每个车机对内部继续调用已经通过自动验证的单车单机时空状态网络；外层枚举小规模任务分配，并按以下顺序严格字典序优化：

```text
系统完工时间 → 总换电次数 → 无人机总活动时间 → 无人车总行驶时间
```

本阶段尚未加入单服务位竞争、无人车能量、任务方向选择和单架次多任务。这些约束会继续按顺序逐项加入，不能把当前结果误称为完整的一般多车多机模型。

## 文件

- `multi_vehicle_uav_solver.py`：多车多机任务分配求解器和组合校验器；
- `single_pair_core.py`：已验证的单车单机子问题核心；
- `data/changping_network_tasks.json`：6站5任务网络与任务数据；
- `data/changping_two_pair_config.json`：双车双机、初始配对和资源参数；
- `test_multi_solver.py`：多车多机回归测试；
- `results_two_pair/`：正式运行结果。
- `run_resource_scale_analysis.py`：完整测试1～5个车机对并选择最小资源方案；
- `results_resource_scale/`：规模曲线、逐规模结果和资源建议。

## 运行

```powershell
python multi_vehicle_uav_solver.py
python run_resource_scale_analysis.py
python -m unittest -v
```

常用覆盖参数：

```powershell
python multi_vehicle_uav_solver.py `
  --end-time-min 95 `
  --deadline-policy clip `
  --spare-batteries 2 `
  --output-dir results_end95
```

还可覆盖 `--nest-speed-kmh`、`--uav-speed-mps`、`--uav-endurance-min` 和 `--swap-time-min`。所有覆盖值和实际生效配置都会写入输出目录。

## 输出与校验

- `summary.json`：目标值、任务分配、逐车机结果和校验信息；
- `effective_multi_instance.json`：实际生效的完整配置；
- `initial_pairing_matrix.csv`：初始配对变量 `g_uv`；
- `task_assignment.csv`：任务—无人机—车辆对应关系与服务时刻；
- `combined_timeline.csv`：两个车机对合并后的完整时间线；
- `assignment_trials.csv`：所有候选任务分配及其可行性；
- `validation_checks.csv`：任务唯一性、资源投入、子问题约束、SOC、换电、会合、终点和目标重算检查；
- `pair_results/`：每个车机对的独立详细时间线与验证结果。

## 1～5车机对与资源最小模式

规模分析不会在第一个下降点提前停止，而是完整运行1～5个车机对，再给出两项建议：

- 资源最小方案：先最小化启用车机对数量，再依次优化完工时间、换电、无人机活动和车辆行驶；
- 性能拐点方案：只有新增车机对带来的完工时间改善达到阈值时才继续增加，默认阈值为10%。

规模曲线默认固定每车2组备用电池；程序还会单独测试单车增加备用电池后的结果，写入 `single_pair_battery_tradeoff.csv`。因此报告会分别给出“固定电池容量时的最少车机对”和“允许增加电池时的单车替代方案”。

可通过 `--marginal-threshold-pct` 修改拐点阈值。完整结果位于 `results_resource_scale/resource_scale_matrix.csv` 和 `resource_scale_report.md`。
