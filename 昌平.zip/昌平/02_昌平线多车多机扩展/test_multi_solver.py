import copy
import tempfile
import unittest
from pathlib import Path

from multi_vehicle_uav_solver import (
    apply_multi_overrides,
    load_multi_instance,
    solve_multi,
    validate_multi_instance,
    validate_multi_solution,
    write_multi_outputs,
)
from run_resource_scale_analysis import run_resource_scale_analysis


ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "data" / "changping_two_pair_config.json"


class MultiVehicleUavSolverTests(unittest.TestCase):
    def test_initial_pairing_and_scale(self) -> None:
        data = load_multi_instance(CONFIG)
        self.assertEqual(len(data["resources"]["mobile_nests"]), 2)
        self.assertEqual(len(data["resources"]["uavs"]), 2)
        self.assertEqual(len(data["tasks"]), 5)
        validate_multi_instance(data)

    def test_default_two_pair_solution(self) -> None:
        result = solve_multi(load_multi_instance(CONFIG))
        self.assertTrue(result["feasible"])
        self.assertEqual(result["objective"]["makespan_min"], 95)
        self.assertEqual(result["objective"]["total_swaps"], 3)
        self.assertEqual(result["objective"]["total_uav_active_min"], 115)
        self.assertEqual(result["objective"]["total_vehicle_travel_min"], 100)
        self.assertEqual(
            {row["task_id"] for row in result["task_assignments"]},
            {"T01", "T02", "T03", "T04", "T05"},
        )
        self.assertEqual({row["uav_id"] for row in result["task_assignments"]}, {"U01", "U02"})
        self.assertTrue(result["validation"]["model_constraints_satisfied"])

    def test_pairing_violation_is_rejected(self) -> None:
        data = load_multi_instance(CONFIG)
        data["resources"]["uavs"][1]["assigned_nest_id"] = "B01"
        with self.assertRaisesRegex(ValueError, "g_uv"):
            validate_multi_instance(data)

    def test_shortest_two_pair_window_on_five_minute_grid(self) -> None:
        data_90 = load_multi_instance(CONFIG)
        apply_multi_overrides(data_90, end_time_min=90, deadline_policy="clip")
        self.assertFalse(solve_multi(data_90)["feasible"])

        data_95 = load_multi_instance(CONFIG)
        apply_multi_overrides(data_95, end_time_min=95, deadline_policy="clip")
        result = solve_multi(data_95)
        self.assertTrue(result["feasible"])
        self.assertEqual(result["objective"]["makespan_min"], 95)

    def test_combined_validator_detects_objective_tampering(self) -> None:
        data = load_multi_instance(CONFIG)
        result = solve_multi(data)
        tampered = copy.deepcopy(result)
        tampered["objective"]["total_swaps"] = 999
        validation = validate_multi_solution(data, tampered)
        self.assertFalse(validation["passed"])
        self.assertFalse(validation["checks"]["objective_recalculation"])

    def test_output_package(self) -> None:
        data = load_multi_instance(CONFIG)
        result = solve_multi(data)
        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir) / "multi"
            write_multi_outputs(data, result, output_dir)
            for name in (
                "summary.json",
                "effective_multi_instance.json",
                "initial_pairing_matrix.csv",
                "task_assignment.csv",
                "combined_timeline.csv",
                "assignment_trials.csv",
                "validation_checks.csv",
            ):
                self.assertTrue((output_dir / name).exists(), name)

    def test_resource_scale_and_minimum_resource_mode(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir) / "scale"
            summary = run_resource_scale_analysis(
                config_path=CONFIG,
                output_dir=output_dir,
                max_pairs=5,
                marginal_threshold_pct=10.0,
            )
            self.assertEqual(summary["minimum_resource_recommendation"]["active_pair_count"], 2)
            self.assertEqual(summary["performance_elbow_recommendation"]["active_pair_count"], 3)
            self.assertEqual(
                summary["battery_relaxed_single_pair_recommendation"]["spare_battery_sets"],
                4,
            )
            self.assertTrue((output_dir / "resource_scale_matrix.csv").exists())
            self.assertTrue((output_dir / "single_pair_battery_tradeoff.csv").exists())


if __name__ == "__main__":
    unittest.main()
