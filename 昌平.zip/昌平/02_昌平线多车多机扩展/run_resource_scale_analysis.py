#!/usr/bin/env python3
"""运行1～5个车机对的规模曲线，并给出最小资源与边际收益建议。"""

from __future__ import annotations

import argparse
import copy
import csv
import json
from pathlib import Path
from time import perf_counter
from typing import Any

from multi_vehicle_uav_solver import (
    load_multi_instance,
    solve_multi,
    validate_multi_instance,
    write_multi_outputs,
)


ROOT = Path(__file__).resolve().parent


def resize_identical_pairs(data: dict[str, Any], pair_count: int) -> None:
    if pair_count < 1:
        raise ValueError("pair_count必须至少为1")
    if pair_count > len(data["tasks"]):
        raise ValueError("要求每架无人机至少执行一项任务时，车机对数量不能超过任务数")
    nest_template = copy.deepcopy(data["resources"]["mobile_nests"][0])
    uav_template = copy.deepcopy(data["resources"]["uavs"][0])
    nests: list[dict[str, Any]] = []
    uavs: list[dict[str, Any]] = []
    for index in range(1, pair_count + 1):
        nest_id = f"B{index:02d}"
        uav_id = f"U{index:02d}"
        nest = copy.deepcopy(nest_template)
        nest["nest_id"] = nest_id
        uav = copy.deepcopy(uav_template)
        uav["uav_id"] = uav_id
        uav["assigned_nest_id"] = nest_id
        nests.append(nest)
        uavs.append(uav)
    data["resources"] = {"mobile_nests": nests, "uavs": uavs}
    data["metadata"]["instance_id"] = f"changping_{pair_count}_pair_scale_v1"
    data["multi_model"]["resource_scale_pair_count"] = pair_count
    validate_multi_instance(data)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def build_scale_rows(
    results: list[tuple[int, dict[str, Any]]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    previous_feasible_makespan: int | None = None
    for pair_count, result in results:
        objective = result.get("objective")
        makespan = int(objective["makespan_min"]) if objective else None
        if makespan is not None and previous_feasible_makespan is not None:
            saved = previous_feasible_makespan - makespan
            improvement_pct = round(saved / previous_feasible_makespan * 100, 1)
        else:
            saved = None
            improvement_pct = None
        rows.append(
            {
                "active_pair_count": pair_count,
                "active_vehicle_count": pair_count,
                "active_uav_count": pair_count,
                "feasible": result["feasible"],
                "makespan_min": makespan if makespan is not None else "",
                "total_swaps": objective["total_swaps"] if objective else "",
                "total_uav_active_min": (
                    objective["total_uav_active_min"] if objective else ""
                ),
                "total_vehicle_travel_min": (
                    objective["total_vehicle_travel_min"] if objective else ""
                ),
                "marginal_time_saved_min": saved if saved is not None else "",
                "marginal_improvement_pct": (
                    improvement_pct if improvement_pct is not None else ""
                ),
                "candidate_assignments": result["search_statistics"][
                    "candidate_assignments"
                ],
                "feasible_assignments": result["search_statistics"][
                    "feasible_assignments"
                ],
                "runtime_ms": result["runtime_ms"],
                "validation_passed": result["validation"]["passed"],
                "model_constraints_satisfied": result["validation"][
                    "model_constraints_satisfied"
                ],
            }
        )
        if makespan is not None:
            previous_feasible_makespan = makespan
    return rows


def choose_performance_elbow(
    rows: list[dict[str, Any]], threshold_pct: float
) -> dict[str, Any] | None:
    feasible = [row for row in rows if row["feasible"]]
    if not feasible:
        return None
    recommendation = feasible[0]
    for row in feasible[1:]:
        improvement = row["marginal_improvement_pct"]
        if improvement == "" or float(improvement) < threshold_pct:
            break
        recommendation = row
    return recommendation


def write_scale_svg(path: Path, rows: list[dict[str, Any]]) -> None:
    feasible = [row for row in rows if row["feasible"]]
    width, height = 720, 390
    x_positions = {count: 90 + (count - 1) * 130 for count in range(1, 6)}
    max_makespan = max(float(row["makespan_min"]) for row in feasible)
    points = []
    labels = []
    for row in feasible:
        x = x_positions[int(row["active_pair_count"])]
        y = 300 - float(row["makespan_min"]) / max_makespan * 230
        points.append(f"{x},{y:.1f}")
        labels.append(
            f'<circle cx="{x}" cy="{y:.1f}" r="6" fill="#4472C4"/>'
            f'<text x="{x}" y="{y-12:.1f}" text-anchor="middle" font-size="13">{row["makespan_min"]} min</text>'
        )
    x_labels = "".join(
        f'<text x="{x_positions[count]}" y="330" text-anchor="middle" font-size="14">{count}</text>'
        for count in range(1, 6)
    )
    infeasible = "".join(
        f'<text x="{x_positions[int(row["active_pair_count"])]}" y="280" text-anchor="middle" fill="#C00000" font-size="13">不可行</text>'
        for row in rows
        if not row["feasible"]
    )
    polyline = (
        f'<polyline points="{" ".join(points)}" fill="none" stroke="#4472C4" stroke-width="3"/>'
        if len(points) > 1
        else ""
    )
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
<rect width="100%" height="100%" fill="white"/>
<text x="360" y="28" text-anchor="middle" font-size="20" font-family="Microsoft YaHei">车机对规模与系统完工时间</text>
<line x1="65" y1="300" x2="675" y2="300" stroke="#666"/>
<line x1="65" y1="55" x2="65" y2="300" stroke="#666"/>
{polyline}{''.join(labels)}{infeasible}{x_labels}
<text x="360" y="365" text-anchor="middle" font-size="14">启用车机对数量</text>
<text x="18" y="180" text-anchor="middle" font-size="14" transform="rotate(-90 18 180)">完工时间/min</text>
</svg>'''
    path.write_text(svg, encoding="utf-8")


def write_report(
    path: Path,
    rows: list[dict[str, Any]],
    minimum_resource: dict[str, Any],
    performance_elbow: dict[str, Any],
    threshold_pct: float,
    configured_batteries: int,
    battery_relaxed_single: dict[str, Any] | None,
) -> None:
    lines = [
        "|车机对|可行|完工时间|换电|无人机活动|车辆行驶|新增1对节约时间|边际改善|",
        "|---:|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"|{row['active_pair_count']}|{'是' if row['feasible'] else '否'}|"
            f"{row['makespan_min'] if row['makespan_min'] != '' else '—'}|"
            f"{row['total_swaps'] if row['total_swaps'] != '' else '—'}|"
            f"{row['total_uav_active_min'] if row['total_uav_active_min'] != '' else '—'}|"
            f"{row['total_vehicle_travel_min'] if row['total_vehicle_travel_min'] != '' else '—'}|"
            f"{row['marginal_time_saved_min'] if row['marginal_time_saved_min'] != '' else '—'}|"
            f"{str(row['marginal_improvement_pct'])+'%' if row['marginal_improvement_pct'] != '' else '—'}|"
        )
    report = f"""# 昌平线1～5车机对规模分析

## 结论

程序完整测试了1～5个车机对，没有因中途边际收益下降而提前停止。所有启用车机对均要求至少执行1项任务，全部任务必须恰好完成一次。

在固定每个车机对配备 **{configured_batteries} 组备用电池** 的当前配置下，按“先最小化启用车机对数量，再优化完工时间、换电、无人机活动和车辆行驶”的资源最小模型，推荐启用 **{minimum_resource['active_pair_count']} 个车机对**。该方案在用户输入的135分钟天窗内完成全部任务，完工时间为 {minimum_resource['makespan_min']} 分钟。

如果把备用电池数量也允许调整，则1个车机对在配备 **{battery_relaxed_single['spare_battery_sets'] if battery_relaxed_single else '搜索范围外'} 组备用电池** 时可行{f"，完工时间为 {battery_relaxed_single['makespan_min']} 分钟" if battery_relaxed_single else ''}。因此“最少车机对”结论必须与电池容量输入共同表述：固定每车2组电池时选2对；允许单车配4组电池时可选1对。

若采用边际改善不低于 {threshold_pct:g}% 的性能拐点规则，推荐启用 **{performance_elbow['active_pair_count']} 个车机对**，对应完工时间 {performance_elbow['makespan_min']} 分钟。

![车机对规模曲线](resource_scale_curve.svg)

## 完整结果

{chr(10).join(lines)}

资源最小目标的严格顺序为：

```text
启用车机对数量 → 系统完工时间 → 总换电次数 → 无人机总活动时间 → 无人车总行驶时间
```

性能拐点只作为方案比较规则，不替代用户输入的规划天窗约束。由于本算例只有5项任务且要求每架无人机至少承担1项任务，最多只测试5个车机对。
"""
    path.write_text(report, encoding="utf-8")


def run_resource_scale_analysis(
    *,
    config_path: Path,
    output_dir: Path,
    max_pairs: int = 5,
    marginal_threshold_pct: float = 10.0,
) -> dict[str, Any]:
    started = perf_counter()
    base_data = load_multi_instance(config_path)
    configured_batteries = int(
        base_data["resources"]["mobile_nests"][0]["spare_battery_sets"]
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    results: list[tuple[int, dict[str, Any]]] = []
    for pair_count in range(1, max_pairs + 1):
        data = copy.deepcopy(base_data)
        resize_identical_pairs(data, pair_count)
        result = solve_multi(data)
        write_multi_outputs(data, result, output_dir / f"pair_count_{pair_count:02d}")
        results.append((pair_count, result))
    rows = build_scale_rows(results)
    feasible = [row for row in rows if row["feasible"]]
    if not feasible:
        raise RuntimeError("1～5车机对均无可行解")

    # 资源最小模型：车机对数量优先，其余指标沿用既定字典序。
    minimum_resource = min(
        feasible,
        key=lambda row: (
            int(row["active_pair_count"]),
            int(row["makespan_min"]),
            int(row["total_swaps"]),
            int(row["total_uav_active_min"]),
            int(row["total_vehicle_travel_min"]),
        ),
    )
    performance_elbow = choose_performance_elbow(rows, marginal_threshold_pct)
    if performance_elbow is None:
        raise RuntimeError("无法确定性能拐点")
    battery_trials: list[dict[str, Any]] = []
    battery_relaxed_single: dict[str, Any] | None = None
    for batteries in range(configured_batteries, 6):
        data = copy.deepcopy(base_data)
        resize_identical_pairs(data, 1)
        data["resources"]["mobile_nests"][0]["spare_battery_sets"] = batteries
        result = solve_multi(data)
        objective = result.get("objective")
        row = {
            "active_pair_count": 1,
            "spare_battery_sets": batteries,
            "feasible": result["feasible"],
            "makespan_min": objective["makespan_min"] if objective else "",
            "total_swaps": objective["total_swaps"] if objective else "",
            "runtime_ms": result["runtime_ms"],
            "validation_passed": result["validation"]["passed"],
            "model_constraints_satisfied": result["validation"][
                "model_constraints_satisfied"
            ],
        }
        battery_trials.append(row)
        if result["feasible"] and battery_relaxed_single is None:
            battery_relaxed_single = row
            write_multi_outputs(
                data,
                result,
                output_dir / "single_pair_battery_relaxed",
            )

    write_csv(output_dir / "resource_scale_matrix.csv", rows)
    write_csv(output_dir / "single_pair_battery_tradeoff.csv", battery_trials)
    write_scale_svg(output_dir / "resource_scale_curve.svg", rows)
    write_report(
        output_dir / "resource_scale_report.md",
        rows,
        minimum_resource,
        performance_elbow,
        marginal_threshold_pct,
        configured_batteries,
        battery_relaxed_single,
    )
    summary = {
        "model_version": "multi-pair-resource-selection-v1.0",
        "tested_pair_counts": list(range(1, max_pairs + 1)),
        "planning_end_time_min": base_data["parameters"]["end_time_min"],
        "configured_spare_batteries_per_pair": configured_batteries,
        "minimum_resource_objective_priority": [
            "active_pair_count",
            "makespan_min",
            "total_swaps",
            "total_uav_active_min",
            "total_vehicle_travel_min",
        ],
        "minimum_resource_recommendation": minimum_resource,
        "performance_elbow_threshold_pct": marginal_threshold_pct,
        "performance_elbow_recommendation": performance_elbow,
        "battery_relaxed_single_pair_recommendation": battery_relaxed_single,
        "single_pair_battery_trials": battery_trials,
        "scale_rows": rows,
        "all_execution_outputs_validated": all(
            row["validation_passed"] for row in rows
        ),
        "runtime_ms": round((perf_counter() - started) * 1000, 3),
    }
    (output_dir / "resource_scale_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="昌平线1～5车机对规模与最小资源分析")
    parser.add_argument(
        "--config",
        type=Path,
        default=ROOT / "data" / "changping_two_pair_config.json",
    )
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results_resource_scale")
    parser.add_argument("--max-pairs", type=int, default=5)
    parser.add_argument("--marginal-threshold-pct", type=float, default=10.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    summary = run_resource_scale_analysis(
        config_path=args.config,
        output_dir=args.output_dir,
        max_pairs=args.max_pairs,
        marginal_threshold_pct=args.marginal_threshold_pct,
    )
    minimum = summary["minimum_resource_recommendation"]
    elbow = summary["performance_elbow_recommendation"]
    print(f"最少可行车机对: {minimum['active_pair_count']}")
    print(f"资源最小方案完工时间: {minimum['makespan_min']} min")
    print(f"性能拐点建议车机对: {elbow['active_pair_count']}")
    print(f"规模报告: {(args.output_dir / 'resource_scale_report.md').resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
