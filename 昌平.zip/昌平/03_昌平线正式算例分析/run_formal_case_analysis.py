#!/usr/bin/env python3
"""生成昌平线单车单机与双车双机的正式算例分析成果。"""

from __future__ import annotations

import copy
import csv
import json
import sys
from pathlib import Path
from time import perf_counter
from typing import Any


ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
SINGLE_DIR = PARENT / "01_昌平线单车单机最小实例"
MULTI_DIR = PARENT / "02_昌平线多车多机扩展"
sys.path.insert(0, str(MULTI_DIR))
sys.path.insert(0, str(SINGLE_DIR))

from changping_min_solver import (  # noqa: E402
    apply_parameter_overrides,
    build_context,
    load_instance,
    solve,
    write_outputs,
)
from multi_vehicle_uav_solver import (  # noqa: E402
    apply_multi_overrides,
    load_multi_instance,
    solve_multi,
    write_multi_outputs,
)
from run_resource_scale_analysis import run_resource_scale_analysis  # noqa: E402


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"空结果表: {path.name}")
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def solve_single_scenario(end_time: int, batteries: int) -> tuple[dict[str, Any], dict[str, Any]]:
    data = load_instance(SINGLE_DIR / "data" / "changping_min_instance.json")
    apply_parameter_overrides(
        data,
        end_time_min=end_time,
        spare_batteries=batteries,
        deadline_policy="linked",
    )
    return data, solve(build_context(data))


def search_single_minimum() -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    best_key: tuple[int, ...] | None = None
    best_data: dict[str, Any] | None = None
    best_result: dict[str, Any] | None = None
    for end_time in range(120, 181, 5):
        for batteries in range(2, 6):
            data, result = solve_single_scenario(end_time, batteries)
            objective = result["objective"]
            rows.append(
                {
                    "end_time_min": end_time,
                    "spare_battery_sets": batteries,
                    "feasible": result["feasible"],
                    "completed_task_count": result["task_result"]["completed_task_count"],
                    "finish_time_min": objective["finish_time_min"],
                    "swaps": objective["swaps_used"],
                    "uav_active_min": objective["drone_active_time_min"],
                    "vehicle_travel_min": objective["vehicle_travel_time_min"],
                    "runtime_ms": result["runtime_ms"],
                    "validation_passed": result["validation"]["passed"],
                    "model_constraints_satisfied": result["validation"][
                        "model_constraints_satisfied"
                    ],
                }
            )
            if result["feasible"]:
                key = (
                    end_time,
                    batteries,
                    objective["finish_time_min"],
                    objective["swaps_used"],
                    objective["drone_active_time_min"],
                    objective["vehicle_travel_time_min"],
                )
                if best_key is None or key < best_key:
                    best_key = key
                    best_data = data
                    best_result = result
    if best_data is None or best_result is None:
        raise RuntimeError("单车单机搜索范围内没有完整可行方案")
    return rows, best_data, best_result


def search_multi_minimum(
    base_data: dict[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    best_data: dict[str, Any] | None = None
    best_result: dict[str, Any] | None = None
    for end_time in range(60, 136, 5):
        data = copy.deepcopy(base_data)
        apply_multi_overrides(data, end_time_min=end_time, deadline_policy="clip")
        result = solve_multi(data)
        objective = result.get("objective")
        rows.append(
            {
                "end_time_min": end_time,
                "feasible": result["feasible"],
                "makespan_min": objective["makespan_min"] if objective else "",
                "total_swaps": objective["total_swaps"] if objective else "",
                "total_uav_active_min": objective["total_uav_active_min"] if objective else "",
                "total_vehicle_travel_min": (
                    objective["total_vehicle_travel_min"] if objective else ""
                ),
                "runtime_ms": result["runtime_ms"],
                "validation_passed": result["validation"]["passed"],
                "model_constraints_satisfied": result["validation"][
                    "model_constraints_satisfied"
                ],
            }
        )
        if result["feasible"] and best_result is None:
            best_data = data
            best_result = result
    if best_data is None or best_result is None:
        raise RuntimeError("双车双机搜索范围内没有完整可行方案")
    return rows, best_data, best_result


def multi_sensitivity(base_data: dict[str, Any]) -> list[dict[str, Any]]:
    factors: list[tuple[str, str, list[int | float]]] = [
        ("无人车速度", "nest_speed_kmh", [12, 15, 18]),
        ("无人机速度", "uav_speed_mps", [2.5, 3.0, 3.5]),
        ("无人机续航", "uav_endurance_min", [30, 35, 40]),
        ("换电时间", "swap_time_min", [5, 10, 15]),
        ("每车备用电池", "spare_batteries", [1, 2, 3]),
    ]
    rows: list[dict[str, Any]] = []
    for factor_name, argument, levels in factors:
        for level in levels:
            data = copy.deepcopy(base_data)
            apply_multi_overrides(data, **{argument: level})
            result = solve_multi(data)
            objective = result.get("objective")
            rows.append(
                {
                    "factor": factor_name,
                    "parameter": argument,
                    "level": level,
                    "feasible": result["feasible"],
                    "makespan_min": objective["makespan_min"] if objective else "",
                    "total_swaps": objective["total_swaps"] if objective else "",
                    "total_uav_active_min": (
                        objective["total_uav_active_min"] if objective else ""
                    ),
                    "total_vehicle_travel_min": (
                        objective["total_vehicle_travel_min"] if objective else ""
                    ),
                    "runtime_ms": result["runtime_ms"],
                    "validation_passed": result["validation"]["passed"],
                    "model_constraints_satisfied": result["validation"][
                        "model_constraints_satisfied"
                    ],
                }
            )
    return rows


def concise_single(result: dict[str, Any]) -> dict[str, Any]:
    objective = result["objective"]
    return {
        "feasible": result["feasible"],
        "finish_time_min": objective["finish_time_min"],
        "swaps": objective["swaps_used"],
        "uav_active_min": objective["drone_active_time_min"],
        "vehicle_travel_min": objective["vehicle_travel_time_min"],
        "runtime_ms": result["runtime_ms"],
        "validation_passed": result["validation"]["model_constraints_satisfied"],
    }


def concise_multi(result: dict[str, Any]) -> dict[str, Any]:
    objective = result["objective"]
    return {
        "feasible": result["feasible"],
        "finish_time_min": objective["makespan_min"],
        "swaps": objective["total_swaps"],
        "uav_active_min": objective["total_uav_active_min"],
        "vehicle_travel_min": objective["total_vehicle_travel_min"],
        "runtime_ms": result["runtime_ms"],
        "validation_passed": result["validation"]["model_constraints_satisfied"],
    }


def write_comparison_svg(path: Path, single: dict[str, Any], multi: dict[str, Any]) -> None:
    width, height = 760, 360
    metrics = [
        ("完工时间/min", single["finish_time_min"], multi["finish_time_min"]),
        ("换电次数", single["swaps"], multi["swaps"]),
        ("无人机活动/min", single["uav_active_min"], multi["uav_active_min"]),
        ("车辆行驶/min", single["vehicle_travel_min"], multi["vehicle_travel_min"]),
    ]
    groups: list[str] = []
    for index, (label, one, two) in enumerate(metrics):
        group_x = 85 + index * 165
        max_value = max(float(one), float(two), 1.0)
        one_h = 220 * float(one) / max_value
        two_h = 220 * float(two) / max_value
        groups.append(
            f'<rect x="{group_x}" y="{285-one_h:.1f}" width="48" height="{one_h:.1f}" fill="#4472C4"/>'
            f'<rect x="{group_x+55}" y="{285-two_h:.1f}" width="48" height="{two_h:.1f}" fill="#ED7D31"/>'
            f'<text x="{group_x+24}" y="{275-one_h:.1f}" text-anchor="middle" font-size="13">{one}</text>'
            f'<text x="{group_x+79}" y="{275-two_h:.1f}" text-anchor="middle" font-size="13">{two}</text>'
            f'<text x="{group_x+51}" y="310" text-anchor="middle" font-size="13">{label}</text>'
        )
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
<rect width="100%" height="100%" fill="white"/>
<text x="380" y="26" text-anchor="middle" font-size="19" font-family="Microsoft YaHei">单车单机与双车双机结果对比</text>
<line x1="55" y1="285" x2="735" y2="285" stroke="#666"/>
{''.join(groups)}
<rect x="255" y="330" width="15" height="15" fill="#4472C4"/><text x="276" y="343" font-size="13">单车单机</text>
<rect x="385" y="330" width="15" height="15" fill="#ED7D31"/><text x="406" y="343" font-size="13">双车双机</text>
</svg>'''
    path.write_text(svg, encoding="utf-8")


def write_report(
    path: Path,
    *,
    single: dict[str, Any],
    multi_common: dict[str, Any],
    multi_minimum: dict[str, Any],
    sensitivity: list[dict[str, Any]],
    scale_summary: dict[str, Any],
) -> None:
    reduction = round(
        (single["finish_time_min"] - multi_common["finish_time_min"])
        / single["finish_time_min"]
        * 100,
        1,
    )
    sensitivity_lines = [
        "|因素|水平|可行|完工时间|换电|无人机活动|车辆行驶|",
        "|---|---:|---|---:|---:|---:|---:|",
    ]
    for row in sensitivity:
        sensitivity_lines.append(
            f"|{row['factor']}|{row['level']}|{'是' if row['feasible'] else '否'}|"
            f"{row['makespan_min'] if row['makespan_min'] != '' else '—'}|"
            f"{row['total_swaps'] if row['total_swaps'] != '' else '—'}|"
            f"{row['total_uav_active_min'] if row['total_uav_active_min'] != '' else '—'}|"
            f"{row['total_vehicle_travel_min'] if row['total_vehicle_travel_min'] != '' else '—'}|"
        )
    scale_lines = [
        "|车机对|可行|完工时间|换电|无人机活动|车辆行驶|边际改善|",
        "|---:|---|---:|---:|---:|---:|---:|",
    ]
    for row in scale_summary["scale_rows"]:
        scale_lines.append(
            f"|{row['active_pair_count']}|{'是' if row['feasible'] else '否'}|"
            f"{row['makespan_min'] if row['makespan_min'] != '' else '—'}|"
            f"{row['total_swaps'] if row['total_swaps'] != '' else '—'}|"
            f"{row['total_uav_active_min'] if row['total_uav_active_min'] != '' else '—'}|"
            f"{row['total_vehicle_travel_min'] if row['total_vehicle_travel_min'] != '' else '—'}|"
            f"{str(row['marginal_improvement_pct'])+'%' if row['marginal_improvement_pct'] != '' else '—'}|"
        )
    minimum_resource = scale_summary["minimum_resource_recommendation"]
    performance_elbow = scale_summary["performance_elbow_recommendation"]
    relaxed_single = scale_summary["battery_relaxed_single_pair_recommendation"]
    report = f"""# 昌平线车—机协同巡检正式算例分析

## 1. 分析范围

本报告比较第一阶段单车单机模型与第二阶段双车双机模型。线路均采用昌平西山口—南邵6站5区间和5项巡检任务；站间距离来自北京地铁数据，任务时间窗、巡检时间及资源参数为测试性假设。

双车双机阶段只新增固定初始配对矩阵 `g_uv` 和任务唯一分配，仍保持每架次一项任务。单服务位竞争、无人车能量、任务方向选择和单架次多任务尚未加入。

## 2. 单车单机复跑结论

单车单机在5分钟离散网格上的最短可行天窗为135分钟，配置4组备用电池。完工时间135分钟、换电4次、无人机活动115分钟、无人车行驶50分钟，完整模型验证通过。

## 3. 双车双机扩展结果

双车双机在共同的135分钟天窗下得到完工时间{multi_common['finish_time_min']}分钟、总换电{multi_common['swaps']}次、无人机总活动{multi_common['uav_active_min']}分钟、无人车总行驶{multi_common['vehicle_travel_min']}分钟。30种满足资源投入要求的任务分配中有20种可行，组合验证全部通过。

在EndT=60～135、步长5分钟的搜索中，双车双机最短可行天窗为{multi_minimum['finish_time_min']}分钟；90分钟不可行，95分钟可行。

![单车单机与双车双机对比](comparison_single_vs_multi.svg)

|指标|单车单机|双车双机|变化解释|
|---|---:|---:|---|
|系统完工时间/min|{single['finish_time_min']}|{multi_common['finish_time_min']}|缩短{reduction}%|
|换电次数|{single['swaps']}|{multi_common['swaps']}|任务分摊后减少1次|
|无人机活动时间/min|{single['uav_active_min']}|{multi_common['uav_active_min']}|总飞行作业量基本不变|
|无人车行驶时间/min|{single['vehicle_travel_min']}|{multi_common['vehicle_travel_min']}|两车均走完整走廊，因此翻倍|

结果说明，增加车机对主要通过并行化缩短完工时间，不会自动减少总飞行作业量，并会增加车辆资源占用。现阶段不能仅凭完工时间断言双车方案整体更优，后续应结合车辆能耗与资源成本。

## 4. 1～5车机对规模曲线与资源选择

规模实验固定每个车机对配备2组备用电池，并完整运行1～5对，没有在首次效率下降时提前停止。

{chr(10).join(scale_lines)}

在固定每车2组备用电池的条件下，资源最小模型推荐 **{minimum_resource['active_pair_count']} 对**，完工时间 {minimum_resource['makespan_min']} 分钟；按边际改善不低于10%的拐点规则，推荐 **{performance_elbow['active_pair_count']} 对**，完工时间 {performance_elbow['makespan_min']} 分钟。

需要特别说明：如果允许增加备用电池，单车单机配备 {relaxed_single['spare_battery_sets']} 组备用电池也可在 {relaxed_single['makespan_min']} 分钟完成。因此“最少车机”必须在电池容量给定后求解，不能把备用电池视为无限且无成本资源。

完整规模曲线、逐规模路径和图形位于 `resource_scale/`。

## 5. 双车双机单因素敏感性

下表每次只改变一个参数，其他参数保持双车双机基准值，规划EndT统一为135分钟。

{chr(10).join(sensitivity_lines)}

每车仅1组备用电池时不可行，说明备用电池是当前实例的关键可行性条件。速度、续航和换电时间对完工时间及可行域的具体影响以表中实际结果为准；由于时间按5分钟离散，部分连续参数变化会落在同一离散时长上。

## 6. 正确性与适用性

单车单机和双车双机入选方案均通过任务唯一完成、时间窗、SOC、安全余量、备用电池、车机会合、终点返回和目标重算验证。详细路径与验证表分别保存在 `detailed_results/` 中。

当前结论仅用于验证模型与算法闭环，不能直接解释为昌平线真实运营能力。正式实证前需要用实际巡检工单、无人机性能、车辆运行限制和作业管理规则替换测试性参数。

## 7. 后续扩展顺序

下一步只加入“单服务位或停机位竞争”，完成测试和算例解释后，再依次加入无人车能量、任务正反方向选择和单架次多任务。
"""
    path.write_text(report, encoding="utf-8")


def main() -> int:
    started = perf_counter()
    output_dir = ROOT / "results"
    detail_dir = output_dir / "detailed_results"
    output_dir.mkdir(parents=True, exist_ok=True)
    detail_dir.mkdir(parents=True, exist_ok=True)

    single_search, single_data, single_result = search_single_minimum()
    write_outputs(single_result, detail_dir / "single_pair_minimum")

    multi_base = load_multi_instance(
        MULTI_DIR / "data" / "changping_two_pair_config.json"
    )
    multi_common_result = solve_multi(copy.deepcopy(multi_base))
    write_multi_outputs(
        multi_base,
        multi_common_result,
        detail_dir / "two_pair_common_horizon",
    )
    horizon_search, multi_min_data, multi_min_result = search_multi_minimum(multi_base)
    write_multi_outputs(
        multi_min_data,
        multi_min_result,
        detail_dir / "two_pair_minimum_window",
    )
    sensitivity = multi_sensitivity(multi_base)
    scale_summary = run_resource_scale_analysis(
        config_path=MULTI_DIR / "data" / "changping_two_pair_config.json",
        output_dir=output_dir / "resource_scale",
        max_pairs=5,
        marginal_threshold_pct=10.0,
    )

    single = concise_single(single_result)
    multi_common = concise_multi(multi_common_result)
    multi_minimum = concise_multi(multi_min_result)
    comparison = [
        {"model": "单车单机", "pair_count": 1, **single},
        {"model": "双车双机", "pair_count": 2, **multi_common},
    ]
    write_csv(output_dir / "single_horizon_battery_search.csv", single_search)
    write_csv(output_dir / "multi_horizon_search.csv", horizon_search)
    write_csv(output_dir / "comparison_single_vs_multi.csv", comparison)
    write_csv(output_dir / "multi_sensitivity.csv", sensitivity)
    write_comparison_svg(output_dir / "comparison_single_vs_multi.svg", single, multi_common)
    write_report(
        output_dir / "formal_case_analysis_report.md",
        single=single,
        multi_common=multi_common,
        multi_minimum=multi_minimum,
        sensitivity=sensitivity,
        scale_summary=scale_summary,
    )

    summary = {
        "analysis_scope": "phase_1_single_pair_vs_phase_2_two_pairs",
        "single_pair_minimum": single,
        "two_pair_common_horizon": multi_common,
        "two_pair_minimum_window": multi_minimum,
        "single_pair_validation": single_result["validation"],
        "two_pair_validation": multi_common_result["validation"],
        "two_pair_minimum_validation": multi_min_result["validation"],
        "sensitivity_case_count": len(sensitivity),
        "sensitivity_all_outputs_validated": all(
            row["validation_passed"] for row in sensitivity
        ),
        "resource_scale": scale_summary,
        "total_runtime_ms": round((perf_counter() - started) * 1000, 3),
        "model_limitations": multi_base["multi_model"]["deferred_features"],
    }
    (output_dir / "formal_case_analysis_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"单车单机最短天窗: {single['finish_time_min']} min")
    print(f"双车双机最短天窗: {multi_minimum['finish_time_min']} min")
    print(f"共同135分钟天窗下双车完工: {multi_common['finish_time_min']} min")
    print(f"敏感性场景: {len(sensitivity)}组")
    print(f"报告: {(output_dir / 'formal_case_analysis_report.md').resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
