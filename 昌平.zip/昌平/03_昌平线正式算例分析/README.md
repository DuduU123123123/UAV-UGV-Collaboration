# 昌平线正式算例分析

本目录只存放跨阶段算例分析程序与成果，不与求解器源码混放。

运行：

```powershell
python run_formal_case_analysis.py
```

程序会重新计算而不是手工抄录结果，并生成：

- `results/formal_case_analysis_report.md`：正式中文分析报告；
- `results/formal_case_analysis_summary.json`：核心结论与验证状态；
- `results/comparison_single_vs_multi.csv`：单车单机与双车双机对比；
- `results/comparison_single_vs_multi.svg`：核心指标图；
- `results/single_horizon_battery_search.csv`：单车单机天窗—电池搜索；
- `results/multi_horizon_search.csv`：双车双机最短天窗搜索；
- `results/multi_sensitivity.csv`：双车双机单因素敏感性结果；
- `results/resource_scale/`：1～5车机对规模曲线、最小资源方案和逐规模详细结果；
- `results/detailed_results/`：三个入选方案的配置、排程、完整时间线和自动验证。

程序依赖同级目录 `01_昌平线单车单机最小实例` 与 `02_昌平线多车多机扩展`，请保持三个文件夹同级放置。
